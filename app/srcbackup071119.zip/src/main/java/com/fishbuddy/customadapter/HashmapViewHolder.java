package com.fishbuddy.customadapter;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.media.MediaMetadataRetriever;
import android.media.ThumbnailUtils;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.NetworkOnMainThreadException;
import android.provider.MediaStore;
import android.text.Html;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.TextUtils;
import android.text.method.LinkMovementMethod;
import android.text.style.ClickableSpan;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewTreeObserver;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.toolbox.ImageLoader;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.fishbuddy.Activities.Sign_in_Sign_up;
import com.fishbuddy.R;
import com.fishbuddy.circularimageview.CircularImageView;
import com.fishbuddy.customfonts.AppController;
import com.fishbuddy.customfonts.CustomBoldTextView;
import com.fishbuddy.customfonts.CustomButton;
import com.fishbuddy.customfonts.CustomEditText;
import com.fishbuddy.customfonts.CustomRegularTextView;
import com.fishbuddy.customfonts.FeedImageView;
import com.fishbuddy.database.Database;
import com.fishbuddy.fragments.Addpost;
import com.fishbuddy.fragments.Comments;
import com.fishbuddy.fragments.Fishingspots_details;
import com.fishbuddy.fragments.Followers;
import com.fishbuddy.fragments.Followers_profile;
import com.fishbuddy.fragments.Following;
import com.fishbuddy.fragments.Landing_page;
import com.fishbuddy.fragments.Landingdetails;
import com.fishbuddy.fragments.Profile;
import com.fishbuddy.fragments.Searchpage;
import com.fishbuddy.servicesparsing.CustomProgressbar;
import com.fishbuddy.servicesparsing.HttpPostClass;
import com.fishbuddy.servicesparsing.InterNetChecker;
import com.fishbuddy.servicesparsing.JsonParsing;
import com.fishbuddy.sidemenu.SideMenu;
import com.fishbuddy.storedobjects.StoredObjects;
import com.fishbuddy.storedobjects.StoredUrls;
import com.fishbuddy.videoplayers.VideoViewActivity;
import com.fishbuddy.videoplayers.Youtube_newActivity;

import org.apache.http.NameValuePair;
import org.apache.http.conn.ConnectTimeoutException;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.UnsupportedEncodingException;
import java.net.SocketTimeoutException;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Objects;


import static com.fishbuddy.fragments.Comments.getposdetailslist;
import static com.fishbuddy.sidemenu.SideMenu.getprofilelist;


class HashmapViewHolder extends RecyclerView.ViewHolder {

    private Activity activity;
    HashMapRecycleviewadapter adapter;


    CustomRegularTextView level_txt, count_txt;

    CustomRegularTextView document_txt, image_txt, status_txt;

    Database database;

    //landingpage
    private LinearLayout landing_listitems_lay, share__lay, comment__lay, like__lay;
    private ImageView like_img;
    CustomRegularTextView more_imagestxt;
    FrameLayout framelay_img;
    //Feed
    ImageView post_img,post_img2;

    CircularImageView landing_circular_img;
    private CustomRegularTextView like_txt, dscrption_txt, comments_count_txt, like_txt_count, share_count_txt,profile_updatedtime_txt,share_txt;
    CustomBoldTextView profile_txt;
    ImageView landing_dots_image;
    RecyclerView multiple_images_recycler;

    //fishingspots
    private LinearLayout fishingspots_lay, directions_lay;
    CustomBoldTextView lakename_txt;
    CustomRegularTextView lakelocation_txt,lakedetails_txt, maxdepth_count_txt,area_count_txt;
    CircularImageView lake_image;


    // fishbreeds
    private LinearLayout fishbreed_lay;
    ImageView image_view_icon;
    CustomRegularTextView track_txt;

    //fishing_tricks
    private CustomRegularTextView int_count_txt;
    private ImageView fishingtricks_img;
    RelativeLayout video_play_layout;
    CustomBoldTextView fishing_title_txt;
    CustomRegularTextView fishing_tricks__txt;

    // following
    CircularImageView profile_circular_img;
    CustomButton follow_btn;

    //profile_following
    CircularImageView following_circular_img;
    CustomRegularTextView follwing_profile_name_txt;
    //profile_followers
    LinearLayout followers_profile_lay;
    Bitmap bmThumbnail;
    private static int count = 0;
    CircularImageView followers_circular_img;
    CustomRegularTextView followers_profile_name_txt, fishing_tricks_txt, profile_name_txt;

    // notifications
    LinearLayout notifications_lay;
    CustomRegularTextView ntfc_profile_name_txt;
    String comments_count = "";
    ArrayList<HashMap<String, String>> datalist_test = new ArrayList<>();

    // comments
    CircularImageView commnt_profile_circular_img;
    CustomBoldTextView comment_profile_txt;
    CustomRegularTextView comment_txt,url_txt;
    LinearLayout comments_listitems_lay;



    //Searchpage
    CustomRegularTextView profile_email_txt;
    LinearLayout profile_listitems_lay;
    CustomRecyclerview customRecyclerview;



    ImageLoader imageLoader = AppController.getInstance().getImageLoader();

    HashmapViewHolder(View convertView, String type, final Activity activity) {

        super(convertView);
        this.activity = activity;
        database = new Database(activity);

        customRecyclerview = new CustomRecyclerview(activity);

        if (type.equalsIgnoreCase( "Searchpage" )) {
            profile_circular_img = convertView.findViewById( R.id.profile_circular_img );
            profile_name_txt = convertView.findViewById( R.id.profile_name_txt );
            profile_email_txt = convertView.findViewById( R.id.profile_email_txt );
            profile_listitems_lay = convertView.findViewById( R.id.profile_listitems_lay );
            follow_btn  = convertView.findViewById( R.id.follow_btn );
        }

        if (type.equalsIgnoreCase("landingpage")) {

            landing_listitems_lay = convertView.findViewById(R.id.landing_listitems_lay);
            share__lay = convertView.findViewById(R.id.share__lay);
            comment__lay = convertView.findViewById(R.id.comment__lay);
            like__lay = convertView.findViewById(R.id.like__lay);
            like_img = convertView.findViewById(R.id.like_img);
            landing_circular_img = convertView.findViewById(R.id.landing_circular_img);
            like_txt = convertView.findViewById(R.id.like_txt);
            dscrption_txt = convertView.findViewById(R.id.dscrption_txt);
            comments_count_txt = convertView.findViewById(R.id.comments_count_txt);
            like_txt_count = convertView.findViewById(R.id.like_txt_count);
            share_count_txt = convertView.findViewById(R.id.share_count_txt);
            post_img = convertView.findViewById(R.id.post_img);
            post_img2 = convertView.findViewById( R.id.post_img2);

            profile_txt = convertView.findViewById(R.id.profile_txt);
            url_txt = convertView.findViewById(R.id.url_txt);
            profile_updatedtime_txt =  convertView.findViewById(R.id.profile_updatedtime_txt);
            share_txt  =  convertView.findViewById(R.id.share_txt);
            landing_dots_image = convertView.findViewById(R.id.landing_dots_image);
            multiple_images_recycler= convertView.findViewById(R.id.multiple_images_recycler);
            more_imagestxt = convertView.findViewById(R.id.more_imagestxt);
            framelay_img = convertView.findViewById( R.id.framelay_img );
        }
        if (type.equalsIgnoreCase("fishingspots")) {

            fishingspots_lay = convertView.findViewById(R.id.fishingspots_lay);
            directions_lay = convertView.findViewById(R.id.directions_lay);

            lakename_txt = convertView.findViewById(R.id.lakename_txt);
            lakelocation_txt = convertView.findViewById(R.id.lakelocation_txt);
            lakedetails_txt = convertView.findViewById(R.id.lakedetails_txt);

            lake_image = convertView.findViewById(R.id.lake_image);

            maxdepth_count_txt = convertView.findViewById(R.id.maxdepth_count_txt);
            area_count_txt = convertView.findViewById(R.id.area_count_txt);



        }
        if (type.equalsIgnoreCase("comments")) {

            comment_profile_txt = convertView.findViewById(R.id.comment_profile_txt);
            commnt_profile_circular_img = convertView.findViewById(R.id.commnt_profile_circular_img);
            comment_txt = convertView.findViewById(R.id.comment_txt);
            comments_listitems_lay = convertView.findViewById(R.id.comments_listitems_lay);
        }
        if (type.equalsIgnoreCase("fishbreeds")) {

            fishbreed_lay = convertView.findViewById(R.id.fishbreed_lay);
            image_view_icon = convertView.findViewById(R.id.image_view_icon);
            track_txt = convertView.findViewById(R.id.track_txt);
        }
        if (type.equalsIgnoreCase("multipleimages")) {

            image_view_icon = convertView.findViewById(R.id.image_view_icon);

        }
        if (type.equalsIgnoreCase("fishing_tricks")) {

            int_count_txt = convertView.findViewById(R.id.int_count_txt);
            fishing_tricks_txt = convertView.findViewById(R.id.fishing_tricks_txt);
            fishingtricks_img = convertView.findViewById(R.id.fishingtricks_img);

            video_play_layout = convertView.findViewById(R.id.video_play_layout);
            fishing_title_txt = convertView.findViewById(R.id.fishing_title_txt);
            fishing_tricks__txt = convertView.findViewById(R.id.fishing_tricks__txt);
        }

        if (type.equalsIgnoreCase("following")) {

            profile_circular_img = convertView.findViewById(R.id.profile_circular_img);
            profile_name_txt = convertView.findViewById(R.id.profile_name_txt);
            follow_btn = convertView.findViewById(R.id.follow_btn);
        }
        if (type.equalsIgnoreCase("Followers")) {

            profile_circular_img = convertView.findViewById(R.id.profile_circular_img);
            profile_name_txt = convertView.findViewById(R.id.profile_name_txt);
            follow_btn = convertView.findViewById(R.id.follow_btn);
        }

        if (type.equalsIgnoreCase("profile_followers")) {
            followers_profile_lay = convertView.findViewById(R.id.followers_profile_lay);
            followers_circular_img = convertView.findViewById(R.id.followers_circular_img);
            followers_profile_name_txt = convertView.findViewById(R.id.followers_profile_name_txt);
        }
        if (type.equalsIgnoreCase("profile_following")) {
            followers_profile_lay = convertView.findViewById(R.id.followers_profile_lay);
            following_circular_img = convertView.findViewById(R.id.following_circular_img);
            follwing_profile_name_txt = convertView.findViewById(R.id.follwing_profile_name_txt);
        }
        if (type.equalsIgnoreCase("notifications")) {
            ntfc_profile_name_txt = convertView.findViewById(R.id.ntfc_profile_name_txt);
            notifications_lay = convertView.findViewById(R.id.notifications_lay);

        }
    }

    void assign_data(final ArrayList<HashMap<String, String>> datalist, final int position, String formtype) {

        if (formtype.equalsIgnoreCase( "landingpage" )) {
            landing_listitems_lay.setOnClickListener( new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    fragmentcalling1( new Comments(), datalist, position );
                }
            } );
            share__lay.setOnClickListener( new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                   /* Intent sharingIntent = new Intent(Intent.ACTION_SEND);
                    sharingIntent.setType("text/plain");
                    sharingIntent.putExtra(Intent.EXTRA_TEXT,
                            "www.google.com");
                    sharingIntent.putExtra(Intent.EXTRA_SUBJECT, "Subject");
                    activity.startActivity(Intent.createChooser(sharingIntent, "Share using"));*/

                    Sharepostpopup( activity, datalist, position, datalist.get( position ).get( "post_id" ) );

                }
            } );
            comment__lay.setOnClickListener( new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    fragmentcalling1( new Comments(), datalist, position );
                }
            } );
            comments_count = datalist.get( position ).get( "is_liked" );

            if (comments_count.equalsIgnoreCase( "No" )) {
                like_img.setImageResource( R.drawable.like_button );
                like_txt.setTextColor( activity.getResources().getColor( R.color.lite_color_text ) );
            } else {
                like_img.setImageResource( R.drawable.liked );
                like_txt.setTextColor( activity.getResources().getColor( R.color.orange ) );
            }

            like__lay.setOnClickListener( new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (comments_count.equalsIgnoreCase( "No" )) {
                        if (InterNetChecker.isNetworkAvailable( activity )) {
                            datalist_test = datalist;
                            new LikepostTask().execute( StoredObjects.UserId, datalist.get( position ).get( "post_id" ) );
                           // updateqtydata( datalist, datalist.get( position ), position, "Yes", "landingpage" );

                        } else {
                            StoredObjects.ToastMethod( activity.getResources().getString( R.string.checkinternet ), activity );
                        }
                    } else {
                        //StoredObjects.ToastMethod("Already liked", activity);

                        if (InterNetChecker.isNetworkAvailable( activity )) {
                            datalist_test = datalist;
                            new UnLikepostTask().execute( StoredObjects.UserId, datalist.get( position ).get( "post_id" ) );
                            //updateqtydata( datalist, datalist.get( position ), position, "No", "landingpage" );

                        } else {
                            StoredObjects.ToastMethod( activity.getResources().getString( R.string.checkinternet ), activity );
                        }

                    }


                }

            } );
            profile_txt.setText( datalist.get( position ).get( "posted_by" ) );
            profile_updatedtime_txt.setText( datalist.get( position ).get( "created_at" ) );

            //  dscrption_txt.setText( datalist.get( position ).get( "description" ) );
            String text = datalist.get( position ).get( "description" );

            if (text.length() > 120) {
                // text = text.substring(0, 120) + "...";
                // dscrption_txt.setText(Html.fromHtml(text + "<font color='hash'> <u>View More</u></font>"));
                //  dscrption_txt.setText( datalist.get( position ).get( "description" ) );
                dscrption_txt.setText( text );
                makeTextViewResizable( dscrption_txt, 2, "More", true );

            } else {
                dscrption_txt.setText( text );
            }


            if (datalist.get( position ).get( "description" ).equalsIgnoreCase( "-" )) {
                dscrption_txt.setVisibility( View.GONE );
            } else {
                dscrption_txt.setVisibility( View.VISIBLE );
            }

            if (datalist.get( position ).get( "filename" ).equalsIgnoreCase( "-" )) {
                post_img.setVisibility( View.GONE );
            } else {
                post_img.setVisibility( View.VISIBLE );
            }


            if (datalist.get( position ).get( "title" ).equalsIgnoreCase( "-" )) {
                url_txt.setVisibility( View.GONE );
            } else {
                url_txt.setVisibility( View.VISIBLE );
            }

            url_txt.setText( datalist.get( position ).get( "title" ) );
            comments_count_txt.setText( datalist.get( position ).get( "comments_count" ) );
            like_txt_count.setText( datalist.get( position ).get( "likes" ) );
            share_txt.setText( datalist.get( position ).get( "share_count" ) + " Shares" );


            try {

                ArrayList<HashMap<String, String>> getmultipleimageslist = new ArrayList<>();
                getmultipleimageslist.clear();
                String files = datalist.get( position ).get( "files" );
                getmultipleimageslist = JsonParsing.GetJsonData( files );
                StoredObjects.LogMethod( "<<><>>>>", "><><><><>>size" + getmultipleimageslist.size() );


                if (getmultipleimageslist.size() == 1) {
                    post_img.setVisibility( View.VISIBLE );
                    framelay_img.setVisibility( View.GONE );

                } else {
                   // multiple_images_recycler.setVisibility( View.VISIBLE );
                   // post_img.setVisibility( View.GONE );
                   // customRecyclerview.Assigndatatorecyleviewhashmap1( multiple_images_recycler, getmultipleimageslist, "multipleimages", "Gridnew", 2, StoredObjects.ver_orientation, R.layout.multipleimageslistitem );
                }
                if (getmultipleimageslist.size() > 1) {
                    //  multiple_images_recycler.setVisibility( View.GONE );
                    framelay_img.setVisibility( View.VISIBLE );
                } else {
                    // multiple_images_recycler.setVisibility( View.VISIBLE );
                   // post_img2.setVisibility( View.GONE );
                    // customRecyclerview.Assigndatatorecyleviewhashmap1( multiple_images_recycler, getmultipleimageslist, "multipleimages", "Gridnew", 2, StoredObjects.ver_orientation, R.layout.multipleimageslistitem );
                }

                if (getmultipleimageslist.size() > 2) {
                    more_imagestxt.setVisibility( View.VISIBLE );
                } else {
                    more_imagestxt.setVisibility( View.GONE );
                }

                try {
                    Glide.with( activity )
                            .load( Uri.parse( StoredUrls.Uploadedimages + getmultipleimageslist.get( 0 ).get( "filename" ) ) ) // add your image url
                            .centerCrop() // scale to fill the ImageView and crop any extra
                            .fitCenter() // scale to fit entire image within ImageView
                            .placeholder( R.drawable.splash_logo )
                            .diskCacheStrategy( DiskCacheStrategy.SOURCE )
                            .crossFade()
                            //.override(600,600)
                            .into( post_img );
                    //  adapter.notifyItemInserted(position);
                } catch (Exception e) {
                }

                try {
                    StoredObjects.LogMethod( "<<><>>>>", "><><><><>>123" + getmultipleimageslist.get( 1 ).get( "filename" ) );
                    Glide.with( activity )
                            .load( Uri.parse( StoredUrls.Uploadedimages + datalist.get( position ).get( "filename" ) ) ) // add your image url
                            .centerCrop() // scale to fill the ImageView and crop any extra
                            .fitCenter() // scale to fit entire image within ImageView
                            .placeholder( R.drawable.splash_logo )
                            .diskCacheStrategy( DiskCacheStrategy.SOURCE )
                            .crossFade()
                            //.override(600,600)
                            .into( post_img2 );
                    //  adapter.notifyItemInserted(position);

                } catch (Exception e) {
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }



            landing_dots_image.setOnClickListener( new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    EditDeleteConfirmation( activity, datalist, position );
                }
            } );


           /* if (datalist.get(position).get("filename") != null) {
                post_img.setImageUrl(StoredUrls.Uploadedimages + datalist.get(position).get("filename"), imageLoader);
                post_img.setVisibility(View.VISIBLE);
                post_img
                        .setResponseObserver(new FeedImageView.ResponseObserver() {
                            @Override
                            public void onError() {
                            }

                            @Override
                            public void onSuccess() {
                            }
                        });
            }*/


            try {
                //RequestOptions options = new RequestOptions();
                //options.optionalFitCenter();
                Glide.with( activity )
                        .load( Uri.parse( StoredUrls.Uploadedimages + datalist.get( position ).get( "profile_picture" ) ) ) // add your image url
                        //      .apply(options)
                        .centerCrop() // scale to fill the ImageView and crop any extra
                        .fitCenter() // scale to fit entire image within ImageView
                        .placeholder( R.drawable.man )
                        .into( landing_circular_img );
            } catch (Exception e) {
            }
        }
        if (formtype.equalsIgnoreCase( "multipleimages" )) {


            try {
                StoredObjects.LogMethod( "<<><>>>>", "><><><><>>123" + datalist.get( position ).get( "filename" ) );
                Glide.with( activity )
                        .load( Uri.parse( StoredUrls.Uploadedimages + datalist.get( position ).get( "filename" ) ) ) // add your image url
                        .centerCrop() // scale to fill the ImageView and crop any extra
                        .fitCenter() // scale to fit entire image within ImageView
                        .placeholder( R.drawable.splash_logo )
                        .diskCacheStrategy( DiskCacheStrategy.SOURCE )
                        .crossFade()
                        //.override(600,600)
                        .into( image_view_icon );
                //  adapter.notifyItemInserted(position);

            } catch (Exception e) {
            }



        }

        if (formtype.equalsIgnoreCase("fishingspots")) {

            lakename_txt.setText(datalist.get(position).get("name"));
            lakelocation_txt.setText(datalist.get(position).get("address"));
            lakedetails_txt.setText(datalist.get(position).get("description"));

            area_count_txt.setText(datalist.get(position).get("lat"));
            maxdepth_count_txt.setText(datalist.get(position).get("lat"));

            try {
                ArrayList<HashMap<String, String>> images_array = new ArrayList<>();
                images_array.clear();
                images_array = JsonParsing.GetJsonData(datalist.get( position ).get( "images" ));
                if(images_array.size()>0){
                    Glide.with( activity )
                            .load( Uri.parse( StoredUrls.Uploadedimages + images_array.get(0).get( "image" ) ) ) // add your image url
                            .centerCrop() // scale to fill the ImageView and crop any extra
                            .fitCenter() // scale to fit entire image within ImageView
                            .placeholder( R.drawable.splash_logo )
                            .diskCacheStrategy(DiskCacheStrategy.SOURCE)
                            .crossFade()
                            //.override(600,600)
                            .into( lake_image );
                }

                //  adapter.notifyItemInserted(position);
            } catch (Exception e) {
            }

            fishingspots_lay.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    fragmentcalling1(new Fishingspots_details(),datalist,position);
                }
            });
            directions_lay.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    try {
                        String url = "https://www.google.com/maps/dir/?api=1&destination=" + datalist.get(position).get("lat") + /*"° N" +*/ "," +datalist.get(position).get("lng") /*+ *//*"° W"*/ /*"&travelmode=driving"*/;
                        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                        activity.startActivity(intent);
                    } catch (Exception e) {
                        StoredObjects.ToastMethod(" Address Not found", activity);
                    }
/*
                    new Handler().postDelayed( new Runnable() {
                        @Override
                        public void run() {
                            Uri gmmIntentUri = Uri.parse("geo:25.2744,133.7751?q=");
                            Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
                            mapIntent.setPackage("com.google.android.apps.maps");
                            activity.startActivity(mapIntent);
                        }
                    }, 1000);
*/
                }
            });
        }
        if (formtype.equalsIgnoreCase("fishbreeds")) {

            track_txt.setText(datalist.get( position ).get( "species" ));

            try {
                ArrayList<HashMap<String, String>> images_array = new ArrayList<>();
                images_array.clear();
                images_array = JsonParsing.GetJsonData(datalist.get( position ).get( "images" ));
                if(images_array.size()>0){
                    Glide.with( activity )
                            .load( Uri.parse( StoredUrls.Uploadedimages + images_array.get(0).get( "image" ) ) ) // add your image url
                            .centerCrop() // scale to fill the ImageView and crop any extra
                            .fitCenter() // scale to fit entire image within ImageView
                            .placeholder( R.drawable.splash_logo )
                            .diskCacheStrategy(DiskCacheStrategy.SOURCE)
                            .crossFade()
                            //.override(600,600)
                            .into( image_view_icon );
                }else{

                }

                //  adapter.notifyItemInserted(position);
            } catch (Exception e) {
            }

            fishbreed_lay.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    fishbreeds_details_popup(activity,datalist,position);
                }
            });
            //track_txt.setText( datalist.get( position ).get( "name" ) );
        }
        if (formtype.equalsIgnoreCase("fishing_tricks")) {
            int_count_txt.setText(Integer.toString(position));

            fishing_title_txt.setText(datalist.get(position).get("title"));
            //fishing_tricks__txt.setText(datalist.get(position).get("description"));


            String text = datalist.get(position).get("description");

            if (text.length() > 120) {
                // text = text.substring(0, 120) + "...";
                // dscrption_txt.setText(Html.fromHtml(text + "<font color='hash'> <u>View More</u></font>"));
                //  dscrption_txt.setText( datalist.get( position ).get( "description" ) );
                fishing_tricks__txt.setText(text);
                makeTextViewResizable(fishing_tricks__txt, 4, "More", true);

            } else {
                fishing_tricks__txt.setText(text);
            }




            if(datalist.get(position).get("file_type").equalsIgnoreCase("Mp4")){


                if(datalist.get(position).get( "video_file" ).equalsIgnoreCase("-")){
                    video_play_layout.setVisibility(View.GONE);
                    fishingtricks_img.setVisibility(View.GONE);

                }else{
                    video_play_layout.setVisibility(View.VISIBLE);
                }

            }else if(datalist.get(position).get("file_type").equalsIgnoreCase("Youtube")){
                video_play_layout.setVisibility(View.VISIBLE);

                try {

                    String youtube_link = StoredObjects.getYouTubeId(datalist.get(position).get( "video_file" ));
                    String image_link = "https://img.youtube.com/vi/"+youtube_link+"/hqdefault.jpg";
                    Glide.with( activity )
                            .load( Uri.parse( image_link ) ) // add your image url
                            .centerCrop() // scale to fill the ImageView and crop any extra
                            .fitCenter() // scale to fit entire image within ImageView
                            .placeholder( R.drawable.splash_logo )
                            .diskCacheStrategy(DiskCacheStrategy.SOURCE)
                            .crossFade()
                            //.override(600,600)
                            .into( fishingtricks_img );
                }catch (Exception e){

                }



            }else if(datalist.get(position).get("file_type").equalsIgnoreCase("Image")){
                video_play_layout.setVisibility(View.GONE);

                try {
                    Glide.with( activity )
                            .load( Uri.parse( StoredUrls.Uploadedimages + datalist.get(position).get( "video_file" ) ) ) // add your image url
                            .centerCrop() // scale to fill the ImageView and crop any extra
                            .fitCenter() // scale to fit entire image within ImageView
                            .placeholder( R.drawable.splash_logo )
                            .diskCacheStrategy(DiskCacheStrategy.SOURCE)
                            .crossFade()
                            //.override(600,600)
                            .into( fishingtricks_img );
                }catch (Exception e){

                }
            }


            video_play_layout.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {


                    if(datalist.get(position).get("file_type").equalsIgnoreCase("Youtube")){
                        StoredUrls.youtubelink = datalist.get(position).get( "video_file" );
                        activity.startActivity(new Intent(activity, Youtube_newActivity.class));

                    }else if(datalist.get(position).get("file_type").equalsIgnoreCase("Mp4")){
                        Intent intent = new Intent(activity, VideoViewActivity.class);
                        intent.putExtra("media_file", StoredUrls.Uploadedimages+datalist.get(position).get( "video_file" ));
                        activity.startActivity(intent);
                    }

                }
            });









           /* RelativeLayout video_play_layout;
            CustomBoldTextView fishing_title_txt;
            CustomRegularTextView fishing_tricks__txt;*/

          /*  Bitmap thumb = ThumbnailUtils.createVideoThumbnail("https://www.youtube.com/watch?v=uilkmUoXoLU",
                    MediaStore.Images.Thumbnails.MINI_KIND);
            fishingtricks_img.setImageBitmap( thumb );*/
/*
            Glide.with(activity)
                    .load("https://www.youtube.com/watch?v=uilkmUoXoLU") // or URI/path
                    .into(fishingtricks_img);
*/

/*
            Glide.with(activity)
                    .load("file:///storage/emulated/0/WhatsApp/Media/WhatsApp Video/VID-20190923-WA0000.mp4")
                    .centerCrop()
                    .placeholder(Color.BLUE)
                    .crossFade()
                    .into(fishingtricks_img);
*/
        }
        if (formtype.equalsIgnoreCase("following")) {
            profile_circular_img.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    fragmentcalling1(new Followers_profile(), datalist, position);
                }
            });
            profile_name_txt.setText(datalist.get(position).get("name"));

            try {
                Glide.with(activity)
                        .load(Uri.parse(StoredUrls.Uploadedimages +datalist.get(position).get("image"))) // add your image url
                        .centerCrop() // scale to fill the ImageView and crop any extra
                        .fitCenter() // scale to fit entire image within ImageView
                        .placeholder(R.drawable.man)
                        .into(profile_circular_img);
            } catch (Exception e) {
            }


            if( datalist.get(position).get("is_following").equalsIgnoreCase("Yes")){
                follow_btn.setText(R.string.unfollow);
            }else{
                follow_btn.setText(R.string.follow);
            }

            follow_btn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {


                    if( datalist.get(position).get("is_following").equalsIgnoreCase("Yes")){
                        follow_btn.setText(R.string.following);

                        if (InterNetChecker.isNetworkAvailable(activity)) {
                            new UnFollowTask().execute(datalist.get(position).get("customer_id"));
                        } else {
                            StoredObjects.ToastMethod(activity.getResources().getString(R.string.checkinternet), activity);
                        }
                        updateqtydata(datalist,datalist.get(position),position,"No","following_profile");

                    }else{

                        if (InterNetChecker.isNetworkAvailable(activity)) {
                            new FollowTask().execute(StoredObjects.UserId, datalist.get(position).get("customer_id"));
                        } else {
                            StoredObjects.ToastMethod(activity.getResources().getString(R.string.checkinternet), activity);
                        }
                    }



                }
            });





        }
        if (formtype.equalsIgnoreCase("Followers")) {
            String id = "";
            id = datalist.get(position).get("customer_id");
            final String finalId = id;


            profile_circular_img.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    fragmentcalling1(new Followers_profile(), datalist, position);
                }
            });

            profile_name_txt.setText(datalist.get(position).get("name"));

            try {
                Glide.with(activity)
                        .load(Uri.parse(StoredUrls.Uploadedimages +datalist.get(position).get("image"))) // add your image url
                        .centerCrop() // scale to fill the ImageView and crop any extra
                        .fitCenter() // scale to fit entire image within ImageView
                        .placeholder(R.drawable.man)
                        .into(profile_circular_img);
            } catch (Exception e) {
            }


            if( datalist.get(position).get("is_following").equalsIgnoreCase("Yes")){
                follow_btn.setText(R.string.unfollow);
            }else{
                follow_btn.setText(R.string.follow);
            }



            follow_btn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    if( datalist.get(position).get("is_following").equalsIgnoreCase("Yes")){
                        follow_btn.setText(R.string.following);

                        if (InterNetChecker.isNetworkAvailable(activity)) {
                            new UnFollowTask().execute(datalist.get(position).get("customer_id"));
                        } else {
                            StoredObjects.ToastMethod(activity.getResources().getString(R.string.checkinternet), activity);
                        }
                        updateqtydata(datalist,datalist.get(position),position,"No","followers_profile");

                    }else{

                        if (InterNetChecker.isNetworkAvailable(activity)) {
                            new FollowTask().execute(StoredObjects.UserId, datalist.get(position).get("customer_id"));
                        } else {
                            StoredObjects.ToastMethod(activity.getResources().getString(R.string.checkinternet), activity);
                        }
                        updateqtydata(datalist,datalist.get(position),position,"Yes","followers_profile");
                    }
                }
            });

        }
        if (formtype.equalsIgnoreCase("profile_followers")) {
            followers_profile_lay.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    fragmentcalling1(new Followers_profile(), datalist, position);
                }
            });
            followers_profile_name_txt.setText(datalist.get(position).get("name"));
            try {
                Glide.with(activity)
                        .load(Uri.parse(StoredUrls.Uploadedimages +datalist.get(position).get("image"))) // add your image url
                        .centerCrop() // scale to fill the ImageView and crop any extra
                        .fitCenter() // scale to fit entire image within ImageView
                        .placeholder(R.drawable.man)
                        .into(followers_circular_img);
            } catch (Exception e) {
            }

        }
        if (formtype.equalsIgnoreCase("profile_following")) {
            followers_profile_lay.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    fragmentcalling1(new Followers_profile(), datalist, position);
                }
            });

            follwing_profile_name_txt.setText(datalist.get(position).get("name"));
            try {
                Glide.with(activity)
                        .load(Uri.parse(StoredUrls.Uploadedimages +datalist.get(position).get("image"))) // add your image url
                        .centerCrop() // scale to fill the ImageView and crop any extra
                        .fitCenter() // scale to fit entire image within ImageView
                        .placeholder(R.drawable.man)
                        .into(following_circular_img);
            } catch (Exception e) {
            }
        }

        if (formtype.equalsIgnoreCase("notifications")) {
            ntfc_profile_name_txt.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    fragmentcalling1(new Followers_profile(), datalist, position);
                }
            });
        }

        if (formtype.equalsIgnoreCase("comments")) {
            comment_profile_txt.setText(datalist.get(position).get("name"));
            comment_txt.setText( datalist.get( position).get( "comments" ) );
            try {
                Glide.with(activity)
                        .load(Uri.parse(StoredUrls.Uploadedimages +datalist.get(position).get("customer_picture"))) // add your image url
                        .centerCrop() // scale to fill the ImageView and crop any extra
                        .fitCenter() // scale to fit entire image within ImageView
                        .placeholder(R.drawable.man)
                        .into(commnt_profile_circular_img);
            } catch (Exception e) {
            }

            commnt_profile_circular_img.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    if (datalist.get(position).get("customer_id").equalsIgnoreCase(StoredObjects.UserId)) {
                        fragmentcalling(new Profile());
                    } else {

                        fragmentcalling1(new Followers_profile(), datalist, position);
                    }
                }
            });

            if (datalist.get( position ).get( "customer_id" ).equalsIgnoreCase(StoredObjects.UserId)){
                comments_listitems_lay.setOnLongClickListener( new View.OnLongClickListener() {
                    @Override
                    public boolean onLongClick(View view) {
                        CommentEditDeleteConfirmation( activity,datalist,position );
                        return false;
                    }
                } );

            }
            else {
                comments_listitems_lay.setOnLongClickListener( new View.OnLongClickListener() {
                    @Override
                    public boolean onLongClick(View view) {
                        Toast.makeText( activity, "You are not suposed to edit/delete", Toast.LENGTH_SHORT ).show();
                        return false;
                    }
                } );
            }



        }
        if (formtype.equalsIgnoreCase("Searchpage")) {
            profile_name_txt.setText( datalist.get( position).get( "name" ) );
            profile_email_txt.setText( datalist.get( position).get( "email" ) );
            try{
                Glide.with(activity )
                        .load(Uri.parse(datalist.get(position).get("image"))) // add your image url
                        .centerCrop() // scale to fill the ImageView and crop any extra
                        .fitCenter() // scale to fit entire image within ImageView
                        .placeholder(R.drawable.imagenotfound)
                        .into(profile_circular_img);
            }catch (Exception e){
            }


            if( datalist.get(position).get("is_following").equalsIgnoreCase("Yes")){
                follow_btn.setText(R.string.unfollow);
            }else{
                follow_btn.setText(R.string.follow);
            }



            follow_btn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    if( datalist.get(position).get("is_following").equalsIgnoreCase("Yes")){
                        follow_btn.setText(R.string.following);

                        if (InterNetChecker.isNetworkAvailable(activity)) {
                            new UnFollowTask().execute(datalist.get(position).get("customer_id"));
                        } else {
                            StoredObjects.ToastMethod(activity.getResources().getString(R.string.checkinternet), activity);
                        }
                        updateqtydata(datalist,datalist.get(position),position,"No","followers_profile_search");

                    }else{

                        if (InterNetChecker.isNetworkAvailable(activity)) {
                            new FollowTask().execute(StoredObjects.UserId, datalist.get(position).get("customer_id"));
                        } else {
                            StoredObjects.ToastMethod(activity.getResources().getString(R.string.checkinternet), activity);
                        }
                        updateqtydata(datalist,datalist.get(position),position,"Yes","followers_profile_search");
                    }
                }
            });


            profile_listitems_lay.setOnClickListener( new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                   /* if (datalist.get( position ).get( "customer_id" ).equalsIgnoreCase( StoredObjects.UserId ))
                    {
                        fragmentcalling( new Profile() );
                    }
                    else {

                        fragmentcalling1( new Followers_profile(), datalist, position );
                    }*/

                }
            } );

        }





    }

    private void fragmentcalling(Fragment fragment) {
        FragmentManager fragmentManager = ((FragmentActivity) activity).getSupportFragmentManager();
        fragmentManager.beginTransaction().replace(R.id.frame_container, fragment).addToBackStack("").commit();
    }

    public void fragmentcalling1(Fragment fragment, ArrayList<HashMap<String, String>> list, int position) {
        FragmentManager fragmentManager = ((FragmentActivity) activity).getSupportFragmentManager();
        Bundle bundle = new Bundle();
        bundle.putSerializable("YourHashMap", list);
        bundle.putInt("position", position);
        fragment.setArguments(bundle);
        fragmentManager.beginTransaction().replace(R.id.frame_container, fragment).addToBackStack("").commit();
    }


    public void fragmentcalling(Fragment fragment, String name, String email, String phone, String image, String catches) {

        FragmentManager fragmentManager = ((FragmentActivity) activity).getSupportFragmentManager();
        Bundle bundle = new Bundle();
        //  bundle.putParcelableArrayList("mylist", (ArrayList<? extends Parcelable>) dumpData);
        bundle.putString("name", name);
        bundle.putString("email", email);
        bundle.putString("phone", phone);
        bundle.putString("image", image);
        bundle.putString("catches", catches);
        fragment.setArguments(bundle);
        fragmentManager.beginTransaction().replace(R.id.frame_container, fragment).addToBackStack("").commit();

    }

    private void fishbreeds_details_popup(final Activity activity, final ArrayList<HashMap<String, String>> data_array, final int position) {
        final Dialog dialog = new Dialog(activity);
        dialog.getWindow();
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.fishbreeddetails_popup);
        Objects.requireNonNull(dialog.getWindow()).setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.getWindow().setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);

        CustomButton fishbreed_additiondetails_btn = (CustomButton) dialog.findViewById(R.id.fishbreed_additiondetails_btn);
        ImageView canclimg = (ImageView) dialog.findViewById(R.id.canclimg);
        ImageView fishbreed_img = (ImageView) dialog.findViewById(R.id.fishbreed_img);



        CustomRegularTextView lakelocation_txt,season_month_txt,bag_limit_txt,
                min_size_txt,max_size_txt,trophy_count_txt,measure_count_txt,record_count_txt;

        CustomBoldTextView fishname_txt =  dialog.findViewById(R.id.fishname_txt);
        lakelocation_txt =  dialog.findViewById(R.id.lakelocation_txt);
        season_month_txt =  dialog.findViewById(R.id.season_month_txt);
        bag_limit_txt =  dialog.findViewById(R.id.bag_limit_count_txt);
        min_size_txt =  dialog.findViewById(R.id.min_size_count_txt);
        max_size_txt =  dialog.findViewById(R.id.max_size_count_txt);
        trophy_count_txt =  dialog.findViewById(R.id.trophy_count_txt);
        measure_count_txt =  dialog.findViewById(R.id.measure_count_txt);
        record_count_txt =  dialog.findViewById(R.id.record_count_txt);


        fishname_txt.setText(data_array.get( position ).get( "species" ));
        lakelocation_txt.setText(data_array.get( position ).get( "season" ));
        season_month_txt.setText(data_array.get( position ).get( "season" ));
        bag_limit_txt.setText(data_array.get( position ).get( "season" ));
        min_size_txt.setText(data_array.get( position ).get( "weight" ));
        max_size_txt.setText(data_array.get( position ).get( "length" ));
        trophy_count_txt.setText(data_array.get( position ).get( "season" ));
        measure_count_txt.setText(data_array.get( position ).get( "season" ));
        record_count_txt.setText(data_array.get( position ).get( "uk_record" ));

        try {
            ArrayList<HashMap<String, String>> images_array = new ArrayList<>();
            images_array.clear();
            images_array = JsonParsing.GetJsonData(data_array.get( position ).get( "images" ));
            if(images_array.size()>0){
                Glide.with( activity )
                        .load( Uri.parse( StoredUrls.Uploadedimages + images_array.get(0).get( "image" ) ) ) // add your image url
                        .centerCrop() // scale to fill the ImageView and crop any extra
                        .fitCenter() // scale to fit entire image within ImageView
                        .placeholder( R.drawable.splash_logo )
                        .diskCacheStrategy(DiskCacheStrategy.SOURCE)
                        .crossFade()
                        //.override(600,600)
                        .into( fishbreed_img );
            }else{

            }

            //  adapter.notifyItemInserted(position);
        } catch (Exception e) {
        }

        fishbreed_additiondetails_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                fishbreeds_additionaldetails_popup(activity,data_array,position);
                dialog.dismiss();
            }
        });

        canclimg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss();
            }
        });
        dialog.show();
    }

    private void fishbreeds_additionaldetails_popup(final Activity activity,ArrayList<HashMap<String, String>> data_array,int position) {
        final Dialog dialog = new Dialog(activity);
        dialog.getWindow();
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.fishbreed_additiondetails_popup);
        Objects.requireNonNull(dialog.getWindow()).setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.getWindow().setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);

        ImageView canclimg = (ImageView) dialog.findViewById(R.id.canclimg);
        CustomRegularTextView fishname_txt =(CustomRegularTextView)dialog.findViewById( R.id.fishname_txt );
        CustomRegularTextView fish_details_txt =(CustomRegularTextView)dialog.findViewById( R.id.fish_details_txt );

        fishname_txt.setText(data_array.get( position ).get( "species" ));
        fish_details_txt.setText(data_array.get( position ).get( "extra_info" ));


        canclimg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss();
            }
        });
        dialog.show();
    }

    public class FollowTask extends AsyncTask<String, String, String> {
        String strResult = "";

        @Override
        protected void onPreExecute() {
            CustomProgressbar.Progressbarshow(activity);
        }

        @Override
        protected String doInBackground(String... params) {
            try {
                List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(2);
                nameValuePairs.add(new BasicNameValuePair("token", "Mikel"));
                nameValuePairs.add(new BasicNameValuePair("method", StoredUrls.follow_profile));
                nameValuePairs.add(new BasicNameValuePair("followed_by", params[0]));
                nameValuePairs.add(new BasicNameValuePair("followed_to", params[1]));
                strResult = HttpPostClass.PostMethod(StoredUrls.BaseUrl, nameValuePairs);
            } catch (URISyntaxException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } catch (SocketTimeoutException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } catch (ConnectTimeoutException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } catch (UnsupportedEncodingException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            return strResult;
        }

        protected void onPostExecute(String result) {
            if (result != null) {
                CustomProgressbar.Progressbarcancel(activity);
            }
            try {

                JSONObject jsonObject = new JSONObject(result);
                String status = jsonObject.getString("status");
                if (status.equalsIgnoreCase("200")) {
                    //String results = jsonObject.getString( "results" );
                    StoredObjects.ToastMethod("Following successfully", activity);
                   // follow_btn.setText(R.string.following);

                } else {
                    String error = jsonObject.getString("error");
                    StoredObjects.ToastMethod(error, activity);
                }


            } catch (JSONException e) {
                e.printStackTrace();
            } catch (NullPointerException e) {
                // TODO: handle exception
            } catch (IllegalStateException e) {
                // TODO: handle exception
            } catch (IllegalArgumentException e) {
                // TODO: handle exception
            } catch (NetworkOnMainThreadException e) {
                // TODO: handle exception
            } catch (RuntimeException e) {
                // TODO: handle exception
            } catch (Exception e) {
                StoredObjects.LogMethod("response", "response:---" + e);
            }
        }
    }


    public class UnFollowTask extends AsyncTask<String, String, String> {
        String strResult = "";

        @Override
        protected void onPreExecute() {
            CustomProgressbar.Progressbarshow(activity);
        }

        @Override
        protected String doInBackground(String... params) {
            try {
                List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(2);
                nameValuePairs.add(new BasicNameValuePair("token", "Mikel"));
                nameValuePairs.add(new BasicNameValuePair("method", StoredUrls.unfollow_user));
                nameValuePairs.add(new BasicNameValuePair("customer_id", StoredObjects.UserId));
                nameValuePairs.add(new BasicNameValuePair("following_customer_id", params[0]));
                strResult = HttpPostClass.PostMethod(StoredUrls.BaseUrl, nameValuePairs);
            } catch (URISyntaxException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } catch (SocketTimeoutException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } catch (ConnectTimeoutException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } catch (UnsupportedEncodingException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            return strResult;
        }

        protected void onPostExecute(String result) {
            if (result != null) {
                CustomProgressbar.Progressbarcancel(activity);
            }
            try {

                JSONObject jsonObject = new JSONObject(result);
                String status = jsonObject.getString("status");
                if (status.equalsIgnoreCase("200")) {
                    //String results = jsonObject.getString( "results" );
                    StoredObjects.ToastMethod("successfully Unfollowed", activity);

                } else {
                    String error = jsonObject.getString("error");
                    StoredObjects.ToastMethod(error, activity);
                }


            } catch (JSONException e) {
                e.printStackTrace();
            } catch (NullPointerException e) {
                // TODO: handle exception
            } catch (IllegalStateException e) {
                // TODO: handle exception
            } catch (IllegalArgumentException e) {
                // TODO: handle exception
            } catch (NetworkOnMainThreadException e) {
                // TODO: handle exception
            } catch (RuntimeException e) {
                // TODO: handle exception
            } catch (Exception e) {
                StoredObjects.LogMethod("response", "response:---" + e);
            }
        }
    }


    public class LikepostTask extends AsyncTask<String, String, String> {
        String strResult = "";

        @Override
        protected void onPreExecute() {
            CustomProgressbar.Progressbarshow(activity);
        }

        @Override
        protected String doInBackground(String... params) {
            try {
                List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(2);
                nameValuePairs.add(new BasicNameValuePair("method", "like-post"));
                nameValuePairs.add(new BasicNameValuePair("customer_id", params[0]));
                nameValuePairs.add(new BasicNameValuePair("post_id", params[1]));
                strResult = HttpPostClass.PostMethod(StoredUrls.BaseUrl, nameValuePairs);
            } catch (URISyntaxException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } catch (SocketTimeoutException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } catch (ConnectTimeoutException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } catch (UnsupportedEncodingException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            return strResult;
        }

        protected void onPostExecute(String result) {
            if (result != null) {
                CustomProgressbar.Progressbarcancel(activity);
            }
            try {

                JSONObject jsonObject = new JSONObject(result);
                String status = jsonObject.getString("status");
                if (status.equalsIgnoreCase("200")) {
                   // StoredObjects.ToastMethod("liked", activity);

                } else {
                    String error = jsonObject.getString("error");
                   // StoredObjects.ToastMethod(error, activity);
                }


            } catch (JSONException e) {
                e.printStackTrace();
            } catch (NullPointerException e) {
                // TODO: handle exception
            } catch (IllegalStateException e) {
                // TODO: handle exception
            } catch (IllegalArgumentException e) {
                // TODO: handle exception
            } catch (NetworkOnMainThreadException e) {
                // TODO: handle exception
            } catch (RuntimeException e) {
                // TODO: handle exception
            } catch (Exception e) {
                StoredObjects.LogMethod("response", "response:---" + e);
            }
        }
    }

    public class UnLikepostTask extends AsyncTask<String, String, String> {
        String strResult = "";

        @Override
        protected void onPreExecute() {
            CustomProgressbar.Progressbarshow(activity);
        }

        @Override
        protected String doInBackground(String... params) {
            try {
                List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(2);
                nameValuePairs.add(new BasicNameValuePair("method", StoredUrls.unlike_post));
                nameValuePairs.add(new BasicNameValuePair("customer_id", params[0]));
                nameValuePairs.add(new BasicNameValuePair("post_id", params[1]));
                strResult = HttpPostClass.PostMethod(StoredUrls.BaseUrl, nameValuePairs);
            } catch (URISyntaxException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } catch (SocketTimeoutException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } catch (ConnectTimeoutException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } catch (UnsupportedEncodingException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            return strResult;
        }

        protected void onPostExecute(String result) {
            if (result != null) {
                CustomProgressbar.Progressbarcancel(activity);
            }
            try {

                JSONObject jsonObject = new JSONObject(result);
                String status = jsonObject.getString("status");
                if (status.equalsIgnoreCase("200")) {
                    // StoredObjects.ToastMethod("liked", activity);

                } else {
                    String error = jsonObject.getString("error");
                    // StoredObjects.ToastMethod(error, activity);
                }


            } catch (JSONException e) {
                e.printStackTrace();
            } catch (NullPointerException e) {
                // TODO: handle exception
            } catch (IllegalStateException e) {
                // TODO: handle exception
            } catch (IllegalArgumentException e) {
                // TODO: handle exception
            } catch (NetworkOnMainThreadException e) {
                // TODO: handle exception
            } catch (RuntimeException e) {
                // TODO: handle exception
            } catch (Exception e) {
                StoredObjects.LogMethod("response", "response:---" + e);
            }
        }
    }

    public void updateqtydata(ArrayList<HashMap<String, String>> list, HashMap<String, String> HashMapdata, int postion, String val, String type) {

        int i = list.indexOf(HashMapdata);

        if (i == -1) {
            throw new IndexOutOfBoundsException();
        }

        if (type.equalsIgnoreCase("landingpage")) {
            HashMap<String, String> dumpData_update = new HashMap<String, String>();
            dumpData_update.put("post_id", HashMapdata.get("post_id"));
            dumpData_update.put("customer_id", HashMapdata.get("customer_id"));
            dumpData_update.put("posted_by", HashMapdata.get("posted_by"));
            dumpData_update.put("profile_picture", HashMapdata.get("profile_picture"));
            dumpData_update.put("title", HashMapdata.get("title"));
            dumpData_update.put("description", HashMapdata.get("description"));
            dumpData_update.put("type", HashMapdata.get("type"));
            dumpData_update.put("filename", HashMapdata.get("filename"));
            dumpData_update.put("is_commented", HashMapdata.get("is_commented"));
            dumpData_update.put("comments_count", HashMapdata.get("comments_count"));
            dumpData_update.put("likes", HashMapdata.get("likes"));
            dumpData_update.put("is_liked", val);

            try{
                if(val.equalsIgnoreCase("Yes")){
                    int likes = Integer.parseInt(HashMapdata.get("likes"));
                    dumpData_update.put("likes", (likes+1)+"");
                }else{
                    int likes = Integer.parseInt(HashMapdata.get("likes"));
                    dumpData_update.put("likes", (likes-1)+"");
                }

            }catch (Exception e){

            }



            list.remove(HashMapdata);
            list.add(postion, dumpData_update);
            //CustomRecyclerview.hashMapRecycleviewadapter.notifyDataSetChanged();
            Landing_page.adapter.notifyDataSetChanged();
        }


        if (type.equalsIgnoreCase("landingpage_delete")) {
            list.remove(HashMapdata);
            Landing_page.adapter.notifyDataSetChanged();
          //  CustomRecyclerview.hashMapRecycleviewadapter.notifyDataSetChanged();
        }
        if (type.equalsIgnoreCase("editcomment")) {
            HashMap<String, String> dumpData_update = new HashMap<String, String>();
            dumpData_update.put("post_id", HashMapdata.get("post_id"));
            dumpData_update.put("customer_id", HashMapdata.get("customer_id"));
            dumpData_update.put("customer_picture", HashMapdata.get("customer_picture"));
            dumpData_update.put("type", HashMapdata.get("type"));
            dumpData_update.put("created_at", HashMapdata.get("created_at"));
            dumpData_update.put("id", HashMapdata.get("id"));
            dumpData_update.put("name", HashMapdata.get("name"));
            dumpData_update.put("comments", val);

            list.remove(HashMapdata);
            list.add(postion, dumpData_update);
            Comments.adapter.notifyDataSetChanged();
        }

        if (type.equalsIgnoreCase("comment_delete")) {
            list.remove(HashMapdata);
            Comments.adapter.notifyDataSetChanged();
        }



        if (type.equalsIgnoreCase("following_profile")) {
            list.remove(HashMapdata);
            Following.adapter.notifyDataSetChanged();
            //  CustomRecyclerview.hashMapRecycleviewadapter.notifyDataSetChanged();
        }



        if (type.equalsIgnoreCase("followers_profile")) {
            HashMap<String, String> dumpData_update = new HashMap<String, String>();
            dumpData_update.put("customer_id", HashMapdata.get("customer_id"));
            dumpData_update.put("name", HashMapdata.get("name"));
            dumpData_update.put("email", HashMapdata.get("email"));
            dumpData_update.put("phone", HashMapdata.get("phone"));
            dumpData_update.put("image", HashMapdata.get("image"));
            dumpData_update.put("catches_count", HashMapdata.get("catches_count"));
            dumpData_update.put("catches", HashMapdata.get("catches"));
            dumpData_update.put("is_following", HashMapdata.get("is_following"));
            dumpData_update.put("is_follower", HashMapdata.get("is_follower"));
            dumpData_update.put("followers_count", HashMapdata.get("followers_count"));
            dumpData_update.put("following_count", HashMapdata.get("following_count"));
            dumpData_update.put("is_following", val);

           /* try{
                if(val.equalsIgnoreCase("Yes")){
                    dumpData_update.put("is_following", "No");
                }else{
                    dumpData_update.put("is_following", "Yes");
                }

            }catch (Exception e){

            }*/
            StoredObjects.LogMethod( "response", "response_follwing:---" + dumpData_update.get("is_following"));


            list.remove(HashMapdata);
            list.add(postion, dumpData_update);
            //CustomRecyclerview.hashMapRecycleviewadapter.notifyDataSetChanged();
            Followers.adapter.notifyDataSetChanged();
        }



        if (type.equalsIgnoreCase("followers_profile_search")) {
            HashMap<String, String> dumpData_update = new HashMap<String, String>();
            dumpData_update.put("customer_id", HashMapdata.get("customer_id"));
            dumpData_update.put("name", HashMapdata.get("name"));
            dumpData_update.put("email", HashMapdata.get("email"));
            dumpData_update.put("phone", HashMapdata.get("phone"));
            dumpData_update.put("image", HashMapdata.get("image"));
            dumpData_update.put("catches_count", HashMapdata.get("catches_count"));
            dumpData_update.put("catches", HashMapdata.get("catches"));
            dumpData_update.put("is_following", HashMapdata.get("is_following"));
            dumpData_update.put("is_follower", HashMapdata.get("is_follower"));
            dumpData_update.put("followers_count", HashMapdata.get("followers_count"));
            dumpData_update.put("following_count", HashMapdata.get("following_count"));
            dumpData_update.put("is_following", val);

            list.remove(HashMapdata);
            list.add(postion, dumpData_update);
            //CustomRecyclerview.hashMapRecycleviewadapter.notifyDataSetChanged();
            Searchpage.adapter.notifyDataSetChanged();
        }





    }


    public static void makeTextViewResizable(final TextView tv, final int maxLine, final String expandText, final boolean viewMore) {

        if (tv.getTag() == null) {
            tv.setTag(tv.getText());
        }
        ViewTreeObserver vto = tv.getViewTreeObserver();
        vto.addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {

            @SuppressWarnings("deprecation")
            @Override
            public void onGlobalLayout() {
                String text;
                int lineEndIndex;
                ViewTreeObserver obs = tv.getViewTreeObserver();
                obs.removeGlobalOnLayoutListener(this);
                if (maxLine == 0) {
                    lineEndIndex = tv.getLayout().getLineEnd(0);
                    text = tv.getText().subSequence(0, lineEndIndex - expandText.length() + 1) + " " + expandText;
                } else if (maxLine > 0 && tv.getLineCount() >= maxLine) {
                    lineEndIndex = tv.getLayout().getLineEnd(maxLine - 1);
                    text = tv.getText().subSequence(0, lineEndIndex - expandText.length() + 1) + " " + expandText;
                } else {
                    lineEndIndex = tv.getLayout().getLineEnd(tv.getLayout().getLineCount() - 1);
                    text = tv.getText().subSequence(0, lineEndIndex) + " " + expandText;
                }
                tv.setText(text);
                tv.setMovementMethod(LinkMovementMethod.getInstance());
                tv.setText(
                        addClickablePartTextViewResizable(Html.fromHtml(tv.getText().toString()), tv, lineEndIndex, expandText,
                                viewMore), TextView.BufferType.SPANNABLE);
            }
        });

    }

    private static SpannableStringBuilder addClickablePartTextViewResizable(final Spanned strSpanned, final TextView tv,
                                                                            final int maxLine, final String spanableText, final boolean viewMore) {
        String str = strSpanned.toString();
        SpannableStringBuilder ssb = new SpannableStringBuilder(strSpanned);

        if (str.contains(spanableText)) {
            ssb.setSpan(new ClickableSpan() {

                @Override
                public void onClick(View widget) {
                    tv.setLayoutParams(tv.getLayoutParams());
                    tv.setText(tv.getTag().toString(), TextView.BufferType.SPANNABLE);
                    tv.invalidate();
                    if (viewMore) {
                        makeTextViewResizable(tv, -1, "Less", false);
                    } else {
                        makeTextViewResizable(tv, 3, "More", true);
                    }

                }
            }, str.indexOf(spanableText), str.indexOf(spanableText) + spanableText.length(), 0);

        }
        return ssb;

    }
    private void Sharepostpopup(final Activity activity,final ArrayList<HashMap<String, String>> list, final int position, final String post_id) {
        final Dialog dialog = new Dialog(activity);
        dialog.getWindow();
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.sharepost_confirmation );
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP_MR1) {
            dialog.getWindow().setElevation(20);
        }
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable( Color.TRANSPARENT));
        dialog.getWindow().setGravity(Gravity.BOTTOM);
        dialog.getWindow().setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);

        LinearLayout cancel_lay = (LinearLayout)dialog.findViewById(R.id.cancel_lay);
        ImageView canclimg = (ImageView)dialog.findViewById(R.id.canclimg);
        CustomRegularTextView sharenow_text = (CustomRegularTextView)dialog.findViewById( R.id.sharenow_text );
        CircularImageView profile_circular_img = (CircularImageView)dialog.findViewById( R.id.profile_circular_img );
        CustomRegularTextView profile_name_txt = (CustomRegularTextView)dialog.findViewById( R.id.profile_name_txt );
        CustomRegularTextView share_date_time_txt = (CustomRegularTextView)dialog.findViewById( R.id.share_date_time_txt );
        final CustomEditText commnt_edittxt = (CustomEditText)dialog.findViewById( R.id.commnt_edittxt );


        profile_name_txt.setText( getprofilelist.get( 0 ).get( "name" ) );
        //share_date_time_txt.setText( list.get( position ).get( "created_at") );
        try {
            Glide.with( activity )
                    .load( Uri.parse( StoredUrls.Uploadedimages + getprofilelist.get( 0 ).get( "image" )  ) ) // add your image url
                    .centerCrop() // scale to fill the ImageView and crop any extra
                    .fitCenter() // scale to fit entire image within ImageView
                    .placeholder( R.drawable.man )
                    .into( profile_circular_img );
        } catch (Exception e) {
        }



        cancel_lay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                dialog.dismiss();
            }
        });

        canclimg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                dialog.dismiss();
            }
        });
        sharenow_text.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss();
                if (InterNetChecker.isNetworkAvailable(activity)) {
                    new SharePostTask().execute(post_id,commnt_edittxt.getText().toString());
                }else{
                    StoredObjects.ToastMethod(activity.getResources().getString(R.string.checkinternet),activity);
                }

            }
        });


        dialog.show();
    }

    private void EditDeleteConfirmation(final Activity activity, final ArrayList<HashMap<String, String>> list, final int position) {
        final Dialog dialog = new Dialog(activity);
        dialog.getWindow();
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.editdelete_confirmation );
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP_MR1) {
            dialog.getWindow().setElevation(20);
        }
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable( Color.TRANSPARENT));
        dialog.getWindow().setGravity(Gravity.BOTTOM);
        dialog.getWindow().setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);

        LinearLayout cancel_lay = (LinearLayout)dialog.findViewById(R.id.cancel_lay);

        LinearLayout edit_layout = (LinearLayout)dialog.findViewById(R.id.edit_layout);
        LinearLayout delet_layout = (LinearLayout)dialog.findViewById(R.id.delet_layout);
        LinearLayout blockuser_layout = (LinearLayout)dialog.findViewById(R.id.blockuser_layout);


        if(list.get( position ).get( "customer_id" ).equalsIgnoreCase(StoredObjects.UserId)){
            edit_layout.setVisibility(View.VISIBLE);
            delet_layout.setVisibility(View.VISIBLE);
            blockuser_layout.setVisibility(View.GONE);
        }else{
            edit_layout.setVisibility(View.GONE);
            delet_layout.setVisibility(View.GONE);
            blockuser_layout.setVisibility(View.VISIBLE);
        }


        blockuser_layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss();

                if (InterNetChecker.isNetworkAvailable(activity)) {
                    new BlockUserTask().execute(list.get( position ).get( "customer_id" ));
                }else{
                    StoredObjects.ToastMethod(activity.getResources().getString(R.string.checkinternet),activity);
                }
            }
        });

        edit_layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                fragmentcalling1(new Addpost(),list,position);
                dialog.dismiss();
            }
        });

        delet_layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                dialog.dismiss();
                if (InterNetChecker.isNetworkAvailable(activity)) {
                    new DeletePostTask().execute(list.get( position ).get( "post_id" ));
                    updateqtydata(list,list.get( position ),position,"No","landingpage_delete");
                }else{
                    StoredObjects.ToastMethod(activity.getResources().getString(R.string.checkinternet),activity);
                }

            }
        });



        cancel_lay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                dialog.dismiss();
            }
        });



        dialog.show();
    }





    public class SharePostTask extends AsyncTask<String, String, String> {
        String strResult = "";

        @Override
        protected void onPreExecute() {
            CustomProgressbar.Progressbarshow(activity);
        }

        @Override
        protected String doInBackground(String... params) {
            try {
                List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(2);
                nameValuePairs.add(new BasicNameValuePair("token", "Mikel"));
                nameValuePairs.add(new BasicNameValuePair("method", "share-post"));
                nameValuePairs.add(new BasicNameValuePair("customer_id", StoredObjects.UserId));
                nameValuePairs.add(new BasicNameValuePair("post_id", params[0]));
                nameValuePairs.add(new BasicNameValuePair("share_text", params[1]));

                strResult = HttpPostClass.PostMethod(StoredUrls.BaseUrl, nameValuePairs);
            } catch (URISyntaxException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } catch (SocketTimeoutException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } catch (ConnectTimeoutException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } catch (UnsupportedEncodingException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            return strResult;
        }

        protected void onPostExecute(String result) {
            if (result != null) {
                CustomProgressbar.Progressbarcancel(activity);
            }
            try {

                JSONObject jsonObject = new JSONObject(result);
                String status = jsonObject.getString("status");
                if (status.equalsIgnoreCase("200")) {
                    //String results = jsonObject.getString( "results" );
                    StoredObjects.ToastMethod("Successfully Post Shared.", activity);

                } else {
                    String error = jsonObject.getString("error");
                    StoredObjects.ToastMethod(error, activity);
                }


            } catch (JSONException e) {
                e.printStackTrace();
            } catch (NullPointerException e) {
                // TODO: handle exception
            } catch (IllegalStateException e) {
                // TODO: handle exception
            } catch (IllegalArgumentException e) {
                // TODO: handle exception
            } catch (NetworkOnMainThreadException e) {
                // TODO: handle exception
            } catch (RuntimeException e) {
                // TODO: handle exception
            } catch (Exception e) {
                StoredObjects.LogMethod("response", "response:---" + e);
            }
        }
    }



    public class DeletePostTask extends AsyncTask<String, String, String> {
        String strResult = "";

        @Override
        protected void onPreExecute() {
            CustomProgressbar.Progressbarshow(activity);
        }

        @Override
        protected String doInBackground(String... params) {
            try {
                List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(2);
                nameValuePairs.add(new BasicNameValuePair("token", "Mikel"));
                nameValuePairs.add(new BasicNameValuePair("method", StoredUrls.delete_post));
                nameValuePairs.add(new BasicNameValuePair("customer_id", StoredObjects.UserId));
                nameValuePairs.add(new BasicNameValuePair("post_id", params[0]));
                strResult = HttpPostClass.PostMethod(StoredUrls.BaseUrl, nameValuePairs);
            } catch (URISyntaxException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } catch (SocketTimeoutException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } catch (ConnectTimeoutException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } catch (UnsupportedEncodingException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            return strResult;
        }

        protected void onPostExecute(String result) {
            if (result != null) {
                CustomProgressbar.Progressbarcancel(activity);
            }
            try {

                JSONObject jsonObject = new JSONObject(result);
                String status = jsonObject.getString("status");
                if (status.equalsIgnoreCase("200")) {
                    //String results = jsonObject.getString( "results" );
                    StoredObjects.ToastMethod("Successfully Deleted.", activity);

                } else {
                    String error = jsonObject.getString("error");
                    StoredObjects.ToastMethod(error, activity);
                }


            } catch (JSONException e) {
                e.printStackTrace();
            } catch (NullPointerException e) {
                // TODO: handle exception
            } catch (IllegalStateException e) {
                // TODO: handle exception
            } catch (IllegalArgumentException e) {
                // TODO: handle exception
            } catch (NetworkOnMainThreadException e) {
                // TODO: handle exception
            } catch (RuntimeException e) {
                // TODO: handle exception
            } catch (Exception e) {
                StoredObjects.LogMethod("response", "response:---" + e);
            }
        }
    }


    public class BlockUserTask extends AsyncTask<String, String, String> {
        String strResult = "";

        @Override
        protected void onPreExecute() {
            CustomProgressbar.Progressbarshow(activity);
        }

        @Override
        protected String doInBackground(String... params) {
            try {
                List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(2);
                nameValuePairs.add(new BasicNameValuePair("token", "Mikel"));
                nameValuePairs.add(new BasicNameValuePair("method", StoredUrls.block_user));
                nameValuePairs.add(new BasicNameValuePair("customer_id", StoredObjects.UserId));
                nameValuePairs.add(new BasicNameValuePair("following_customer_id", params[0]));
                strResult = HttpPostClass.PostMethod(StoredUrls.BaseUrl, nameValuePairs);
            } catch (URISyntaxException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } catch (SocketTimeoutException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } catch (ConnectTimeoutException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } catch (UnsupportedEncodingException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            return strResult;
        }

        protected void onPostExecute(String result) {
            if (result != null) {
                CustomProgressbar.Progressbarcancel(activity);
            }
            try {

                JSONObject jsonObject = new JSONObject(result);
                String status = jsonObject.getString("status");
                if (status.equalsIgnoreCase("200")) {
                    //String results = jsonObject.getString( "results" );
                    StoredObjects.ToastMethod("Successfully Blocked.", activity);

                } else {
                    String error = jsonObject.getString("error");
                    StoredObjects.ToastMethod(error, activity);
                }


            } catch (JSONException e) {
                e.printStackTrace();
            } catch (NullPointerException e) {
                // TODO: handle exception
            } catch (IllegalStateException e) {
                // TODO: handle exception
            } catch (IllegalArgumentException e) {
                // TODO: handle exception
            } catch (NetworkOnMainThreadException e) {
                // TODO: handle exception
            } catch (RuntimeException e) {
                // TODO: handle exception
            } catch (Exception e) {
                StoredObjects.LogMethod("response", "response:---" + e);
            }
        }
    }




    private void CommentEditDeleteConfirmation(final Activity activity, final ArrayList<HashMap<String, String>> list, final int position) {
        final Dialog dialog = new Dialog(activity);
        dialog.getWindow();
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.editdelete_confirmation );
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP_MR1) {
            dialog.getWindow().setElevation(20);
        }
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable( Color.TRANSPARENT));
        dialog.getWindow().setGravity(Gravity.BOTTOM);
        dialog.getWindow().setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);

        LinearLayout cancel_lay = (LinearLayout)dialog.findViewById(R.id.cancel_lay);

        LinearLayout edit_layout = (LinearLayout)dialog.findViewById(R.id.edit_layout);
        LinearLayout delet_layout = (LinearLayout)dialog.findViewById(R.id.delet_layout);
        LinearLayout blockuser_layout = (LinearLayout)dialog.findViewById(R.id.blockuser_layout);
        blockuser_layout.setVisibility(View.GONE);

        if(list.get( position ).get( "customer_id" ).equalsIgnoreCase(StoredObjects.UserId)){
            edit_layout.setVisibility(View.VISIBLE);
            delet_layout.setVisibility(View.VISIBLE);
        }


        edit_layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                CommentEditpopup( activity,list,position );
                dialog.dismiss();
            }
        });
        delet_layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                dialog.dismiss();
                if (InterNetChecker.isNetworkAvailable(activity)) {
                    new DeleteCommentTask().execute(getposdetailslist.get( 0 ).get( "post_id" ),list.get( position ).get( "id" ));
                    updateqtydata(list,list.get( position ),position,"No","comment_delete");
                }else{
                    StoredObjects.ToastMethod(activity.getResources().getString(R.string.checkinternet),activity);
                }

            }
        });

        cancel_lay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                dialog.dismiss();
            }
        });



        dialog.show();
    }

    CustomEditText commnt_edittxt;
    private void CommentEditpopup(final Activity activity, final ArrayList<HashMap<String, String>> list, final int position) {
        final Dialog dialog = new Dialog(activity);
        dialog.getWindow();
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.editcommentpopup );
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP_MR1) {
            dialog.getWindow().setElevation(20);
        }
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable( Color.TRANSPARENT));
        dialog.getWindow().setGravity(Gravity.BOTTOM);
        dialog.getWindow().setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);

        LinearLayout cancel_lay = (LinearLayout)dialog.findViewById(R.id.cancel_lay);

         commnt_edittxt = (CustomEditText)dialog.findViewById(R.id.commnt_edittxt);
        ImageView cmntsend_btn = (ImageView)dialog.findViewById(R.id.cmntsend_btn);

        if (commnt_edittxt.hasFocus()) {
            dialog.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
        }


        commnt_edittxt.setText(list.get( position ).get( "comments" ) );
        commnt_edittxt.requestFocus();
        dialog.getWindow().setSoftInputMode( WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE);
        cmntsend_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                dialog.dismiss();
                if (InterNetChecker.isNetworkAvailable(activity)) {
                    new EditCommentTask().execute(getposdetailslist.get( 0 ).get( "post_id" ),list.get( position ).get( "id" ),commnt_edittxt.getText().toString());
                    updateqtydata(list,list.get(position),position,commnt_edittxt.getText().toString(),"editcomment");
                }else{
                    StoredObjects.ToastMethod(activity.getResources().getString(R.string.checkinternet),activity);
                }
            }
        });
        cancel_lay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                dialog.dismiss();
            }
        });

        dialog.show();
    }


    public class EditCommentTask extends AsyncTask<String, String, String> {
        String strResult = "";

        @Override
        protected void onPreExecute() {
            CustomProgressbar.Progressbarshow(activity);
        }

        @Override
        protected String doInBackground(String... params) {
            try {
                List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(2);
                nameValuePairs.add(new BasicNameValuePair("token", "Mikel"));
                nameValuePairs.add(new BasicNameValuePair("method", "edit-comment-on-post"));
                nameValuePairs.add(new BasicNameValuePair("customer_id", StoredObjects.UserId));
                nameValuePairs.add(new BasicNameValuePair("post_id", params[0]));
                nameValuePairs.add(new BasicNameValuePair("comment_id", params[1]));
                nameValuePairs.add(new BasicNameValuePair("comments", params[2]));
                strResult = HttpPostClass.PostMethod(StoredUrls.BaseUrl, nameValuePairs);
            } catch (URISyntaxException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } catch (SocketTimeoutException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } catch (ConnectTimeoutException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } catch (UnsupportedEncodingException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            return strResult;
        }

        protected void onPostExecute(String result) {
            if (result != null) {
                CustomProgressbar.Progressbarcancel(activity);
            }
            try {

                JSONObject jsonObject = new JSONObject(result);
                String status = jsonObject.getString("status");
                if (status.equalsIgnoreCase("200")) {
                    //String results = jsonObject.getString( "results" );
                    StoredObjects.ToastMethod("Successfully Edited.", activity);
                    commnt_edittxt.setText( "" );
                    /*if (InterNetChecker.isNetworkAvailable(activity)) {
                        new Comments.GetPostdetailsTask().execute(StoredObjects.UserId,postid);
                    }else{
                        StoredObjects.ToastMethod(activity.getResources().getString(R.string.checkinternet),activity);
                    }*/

                } else {
                    String error = jsonObject.getString("error");
                    StoredObjects.ToastMethod(error, activity);
                }


            } catch (JSONException e) {
                e.printStackTrace();
            } catch (NullPointerException e) {
                // TODO: handle exception
            } catch (IllegalStateException e) {
                // TODO: handle exception
            } catch (IllegalArgumentException e) {
                // TODO: handle exception
            } catch (NetworkOnMainThreadException e) {
                // TODO: handle exception
            } catch (RuntimeException e) {
                // TODO: handle exception
            } catch (Exception e) {
                StoredObjects.LogMethod("response", "response:---" + e);
            }
        }
    }
    public class DeleteCommentTask extends AsyncTask<String, String, String> {
        String strResult = "";

        @Override
        protected void onPreExecute() {
            CustomProgressbar.Progressbarshow(activity);
        }

        @Override
        protected String doInBackground(String... params) {
            try {
                List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(2);
                nameValuePairs.add(new BasicNameValuePair("token", "Mikel"));
                nameValuePairs.add(new BasicNameValuePair("method", "delete-comment-on-post"));
                nameValuePairs.add(new BasicNameValuePair("customer_id", StoredObjects.UserId));
                nameValuePairs.add(new BasicNameValuePair("post_id", params[0]));
                nameValuePairs.add(new BasicNameValuePair("comment_id", params[1]));
                strResult = HttpPostClass.PostMethod(StoredUrls.BaseUrl, nameValuePairs);
            } catch (URISyntaxException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } catch (SocketTimeoutException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } catch (ConnectTimeoutException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } catch (UnsupportedEncodingException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            return strResult;
        }

        protected void onPostExecute(String result) {
            if (result != null) {
                CustomProgressbar.Progressbarcancel(activity);
            }
            try {

                JSONObject jsonObject = new JSONObject(result);
                String status = jsonObject.getString("status");
                if (status.equalsIgnoreCase("200")) {
                    //String results = jsonObject.getString( "results" );
                    StoredObjects.ToastMethod("Successfully Deleted.", activity);
                   /* if (InterNetChecker.isNetworkAvailable(activity)) {
                        new Comments.GetPostdetailsTask().execute(StoredObjects.UserId,postid);
                    }else{
                        StoredObjects.ToastMethod(activity.getResources().getString(R.string.checkinternet),activity);
                    }*/
                } else {
                    String error = jsonObject.getString("error");
                    StoredObjects.ToastMethod(error, activity);
                }

            } catch (JSONException e) {
                e.printStackTrace();
            } catch (NullPointerException e) {
                // TODO: handle exception
            } catch (IllegalStateException e) {
                // TODO: handle exception
            } catch (IllegalArgumentException e) {
                // TODO: handle exception
            } catch (NetworkOnMainThreadException e) {
                // TODO: handle exception
            } catch (RuntimeException e) {
                // TODO: handle exception
            } catch (Exception e) {
                StoredObjects.LogMethod("response", "response:---" + e);
            }
        }
    }



}
