package com.fishbuddy.fragments;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.fishbuddy.R;
import com.fishbuddy.customfonts.CustomRegularTextView;
import com.fishbuddy.servicesparsing.JsonParsing;
import com.fishbuddy.sidemenu.SideMenu;
import com.fishbuddy.storedobjects.StoredObjects;
import com.fishbuddy.storedobjects.StoredUrls;

import java.util.ArrayList;
import java.util.HashMap;

public class Fishingspots_details extends Fragment {
    TextView title_txt;
    LinearLayout locate_lake_lay;


    Bundle bundle;
    ArrayList<HashMap<String, String>> fishspotdetails;
    int position;


    ImageView lake_image;
    CustomRegularTextView lakedetails_txt,website_txt,email_txt,phone_txt;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate( R.layout.fishingspotsdetails,null,false );
        StoredObjects.page_type="fishingspotsdetails";
        StoredObjects.back_type="fishingspotsdetails";
        SideMenu.updatemenu(StoredObjects.page_type);


        bundle = getArguments();
        try {
            Log.i("hos_id", "hos_id:--"+bundle);
            if (bundle != null) {
                fishspotdetails = (ArrayList<HashMap<String, String>>) bundle.getSerializable("YourHashMap");
                position = bundle.getInt( "position" );

            }
        } catch (Exception e) {
            // TODO: handle exception
        }
        initilization(v);
        dataasign();


        return v;
    }


    public  void dataasign(){


        title_txt.setText(StoredObjects.stripHtml(fishspotdetails.get(position).get("name")));

        //lakelocation_txt.setText(fishspotdetails.get(position).get("address"));
        lakedetails_txt.setText(StoredObjects.stripHtml(fishspotdetails.get(position).get("description")));

      //  area_count_txt.setText(fishspotdetails.get(position).get("lat"));
        //maxdepth_count_txt.setText(fishspotdetails.get(position).get("lat"));

        try {
            ArrayList<HashMap<String, String>> images_array = new ArrayList<>();
            images_array.clear();
            images_array = JsonParsing.GetJsonData(fishspotdetails.get( position ).get( "images" ));
            if(images_array.size()>0){
                Glide.with( getActivity() )
                        .load( Uri.parse( StoredUrls.Uploadedimages + images_array.get(0).get( "image" ) ) ) // add your image url
                        .centerCrop() // scale to fill the ImageView and crop any extra
                        .fitCenter() // scale to fit entire image within ImageView
                        .placeholder( R.drawable.splash_logo_new )
                        .diskCacheStrategy(DiskCacheStrategy.SOURCE)
                        .crossFade()
                        //.override(600,600)
                        .into( lake_image );
            }

            //  adapter.notifyItemInserted(position);
        } catch (Exception e) {
        }

    }

    private void initilization(View v) {

         title_txt = (TextView)v.findViewById( R.id. title_txt);
        title_txt.setText( R.string.lakename );


        lake_image = v.findViewById( R.id. lake_image);
        lakedetails_txt = v.findViewById( R.id. lakedetails_txt);
        website_txt = v.findViewById( R.id. website_txt);
        email_txt = v.findViewById( R.id. email_txt);
        phone_txt = v.findViewById( R.id. phone_txt);
        website_txt.setText(StoredObjects.stripHtml(fishspotdetails.get(position).get("website")));
        email_txt.setText(StoredObjects.stripHtml(fishspotdetails.get(position).get("email")));
        phone_txt.setText(StoredObjects.stripHtml(fishspotdetails.get(position).get("phone")));

        ImageView backbtn_img = (ImageView)v.findViewById( R.id.backbtn_img );
        backbtn_img.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                assert getFragmentManager() != null;
                getFragmentManager().popBackStack();
            }
        } );

        locate_lake_lay = (LinearLayout)v.findViewById( R.id.locate_lake_lay );
        locate_lake_lay.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    //String url = "https://www.google.com/maps/dir/?api=1&destination=" + fishspotdetails.get(position).get("lat") + "° N"+"," + fishspotdetails.get(position).get("lng")+"° W" /*"&travelmode=driving"*/;

                    String url = "https://www.google.com/maps/dir/?api=1&destination=" + fishspotdetails.get(position).get("lat") +"," + fishspotdetails.get(position).get("lng") /*"&travelmode=driving"*/;

                    Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                    getContext().startActivity(intent);
                }catch (Exception e){
                    StoredObjects.ToastMethod("No Lakes found",getActivity());
                }

            }
        } );
    }
}
