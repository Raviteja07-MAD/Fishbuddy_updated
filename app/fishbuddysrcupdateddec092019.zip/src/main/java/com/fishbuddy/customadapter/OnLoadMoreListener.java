package com.fishbuddy.customadapter;

/**
 * Created by shrythi on 4/9/2018.
 */

public interface OnLoadMoreListener {
    void onLoadMore();
}