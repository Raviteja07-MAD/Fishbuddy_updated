package com.fishbuddy.fragments;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;

import com.fishbuddy.R;
import com.fishbuddy.customadapter.CustomRecyclerview;
import com.fishbuddy.sidemenu.SideMenu;
import com.fishbuddy.storedobjects.StoredObjects;

import static com.facebook.FacebookSdk.getApplicationContext;

public class Notifications_settings extends Fragment {
    RecyclerView popular_recyclerview;
    CustomRecyclerview customRecyclerview;
    TextView title_txt;
    Switch switch_on_new_user_followed,switch_comments,switch_newposts,switch_likes;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate( R.layout.notifications_settings,null,false );
        StoredObjects.page_type="home";
        StoredObjects.back_type="notificationssettings";
        SideMenu.updatemenu(StoredObjects.page_type);
        initilization(v);
        return v;
    }

    private void initilization(View v) {
        title_txt = (TextView)v.findViewById( R.id. title_txt);
        title_txt.setText( R.string.notifications_settings );


        switch_on_new_user_followed = (Switch)v.findViewById( R.id.switch_on_new_user_followed );
        switch_comments = (Switch)v.findViewById( R.id.switch_comments );
        switch_newposts = (Switch)v.findViewById( R.id.switch_newposts );
        switch_likes = (Switch)v.findViewById( R.id.switch_likes );

        ImageView backbtn_img = (ImageView)v.findViewById( R.id.backbtn_img );
        backbtn_img.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                assert getFragmentManager() != null;
                getFragmentManager().popBackStack();

            }
        } );

        /*  if(checkbox.equalsIgnoreCase("dont")){
            route_selection_checkbox.setChecked(true);
            StoredObjects.savedata(getActivity(),"dont","checkbox");
        }else{
            route_selection_checkbox.setChecked(false);
            StoredObjects.savedata(getActivity(),"show","checkbox");
        }   */
    }
}
/* String on_new_user_followed = StoredObjects.getsaveddata(getApplicationContext(),"on_new_user_followed");
        String on_another_user_commented_on_your_post = StoredObjects.getsaveddata(getApplicationContext(),"on_another_user_commented_on_your_post");
        String on_new_post_by_user_you_following = StoredObjects.getsaveddata(getApplicationContext(),"on_new_post_by_user_you_following");
        String on_another_user_liked_your_post = StoredObjects.getsaveddata(getApplicationContext(),"on_another_user_liked_your_post");
        String on_new_post_by_your_follower = StoredObjects.getsaveddata(getApplicationContext(),"on_new_post_by_your_follower");*/