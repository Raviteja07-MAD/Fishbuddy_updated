package com.fishbuddy.fragments;

import android.os.AsyncTask;
import android.os.Bundle;
import android.os.NetworkOnMainThreadException;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;

import com.fishbuddy.R;
import com.fishbuddy.customadapter.CustomRecyclerview;
import com.fishbuddy.customadapter.HashMapRecycleviewadapter;
import com.fishbuddy.servicesparsing.CustomProgressbar;
import com.fishbuddy.servicesparsing.HttpPostClass;
import com.fishbuddy.servicesparsing.InterNetChecker;
import com.fishbuddy.servicesparsing.JsonParsing;
import com.fishbuddy.sidemenu.SideMenu;
import com.fishbuddy.storedobjects.StoredObjects;
import com.fishbuddy.storedobjects.StoredUrls;

import org.apache.http.NameValuePair;
import org.apache.http.conn.ConnectTimeoutException;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.net.SocketTimeoutException;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class Searchpage extends Fragment {
    TextView prdct_nodata_txt;
    CustomRecyclerview customRecyclerview;
    LinearLayout backbtn_lay;
    EditText prfle_srch_edtx;
    ImageView cancel_img;
    RecyclerView profile_search_recycle;
    CardView cardview;
    public static HashMapRecycleviewadapter adapter;
    public ArrayList<HashMap<String, String>> userslist = new ArrayList<>();
    public static ArrayList<HashMap<String,String>> searchlistarray = new ArrayList<>();
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate( R.layout.searchpage,null,false );
        StoredObjects.page_type="searchpage";
        StoredObjects.back_type="searchpage";
        SideMenu.updatemenu(StoredObjects.page_type);
        initilization(v);
        if (InterNetChecker.isNetworkAvailable(getActivity())) {

            new GetUsersListTask().execute(StoredObjects.UserId);
        }else{
            StoredObjects.ToastMethod(getActivity().getResources().getString(R.string.checkinternet),getActivity());
        }
        return v;
    }


    private void initilization(View v) {

        profile_search_recycle = (RecyclerView) v.findViewById( R.id.profile_search_recycle );
        customRecyclerview = new CustomRecyclerview(getActivity());
        backbtn_lay = v.findViewById( R.id.backbtn_lay );
        prfle_srch_edtx = v.findViewById( R.id.prfle_srch_edtx );
        cancel_img = v.findViewById( R.id.cancel_img );
        prdct_nodata_txt = v.findViewById( R.id.prdct_nodata_txt );
        cardview = v.findViewById( R.id.cardview );
        cancel_img.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                prfle_srch_edtx.setText( "" );
            }
        } );
        backbtn_lay.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                assert getFragmentManager() != null;
                getFragmentManager().popBackStack();

            }
        } );

        prfle_srch_edtx.addTextChangedListener(new TextWatcher() {


            public void afterTextChanged(Editable s) {
            }

            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            public void onTextChanged(CharSequence s, int start, int before, int count) {
                int textlength = prfle_srch_edtx.getText().length();
                if (textlength>0){
                    cancel_img.setVisibility( View.VISIBLE );
                }
                else {
                    cancel_img.setVisibility( View.GONE );
                }

                searchlistarray.clear();
                for (int i = 0; i < userslist.size(); i++) {
                    if ((textlength <= userslist.get(i).get("name").length())||(textlength <= userslist.get(i).get("email").length())
                            ||(textlength <= userslist.get(i).get("phone").length())) {
                        if ((userslist.get(i).get("name").toLowerCase().trim().contains(  prfle_srch_edtx.getText().toString().toLowerCase().trim()))
                                ||(userslist.get(i).get("email").toLowerCase().trim().contains(prfle_srch_edtx.getText().toString().toLowerCase().trim()))
                                ||(userslist.get(i).get("phone").toLowerCase().trim().contains(prfle_srch_edtx.getText().toString().toLowerCase().trim()))) {
                            searchlistarray.add(userslist.get(i));
                        }
                    }
                }
                StoredObjects.LogMethod( "<><><>","<>><><"+searchlistarray.size()+searchlistarray );

                if (textlength==0){

                    prdct_nodata_txt.setVisibility(View.VISIBLE);
                    profile_search_recycle.setVisibility(View.GONE);
                    cardview.setVisibility(View.GONE);

                }else{

                    if(searchlistarray.size()>0){
                        profile_search_recycle.setVisibility(View.VISIBLE);
                        cardview.setVisibility(View.VISIBLE);
                        prdct_nodata_txt.setVisibility(View.GONE);

                        customRecyclerview.Assigndatatorecyleviewhashmap( profile_search_recycle, searchlistarray, "Searchpage", StoredObjects.Listview, 0, StoredObjects.ver_orientation, R.layout.search_listitems );
                        profile_search_recycle.setVisibility(View.VISIBLE);
                    }else{
                        prdct_nodata_txt.setVisibility(View.VISIBLE);
                        profile_search_recycle.setVisibility(View.GONE);
                        cardview.setVisibility(View.GONE);
                    }
                }


            }
        });


    }

    public class GetUsersListTask extends AsyncTask<String, String, String> {
        String strResult = "";

        @Override
        protected void onPreExecute() {
            CustomProgressbar.Progressbarshow( getActivity());
        }
        @Override
        protected String doInBackground(String... params) {
            try {
                List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>( 2 );
                nameValuePairs.add( new BasicNameValuePair( "token", "Mikel" ) );
                nameValuePairs.add( new BasicNameValuePair( "method", "users-list" ) );
                nameValuePairs.add( new BasicNameValuePair( "customer_id", params[0] ) );
                strResult = HttpPostClass.PostMethod( StoredUrls.BaseUrl, nameValuePairs );
            } catch (URISyntaxException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } catch (SocketTimeoutException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } catch (ConnectTimeoutException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } catch (UnsupportedEncodingException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            return strResult;
        }

        protected void onPostExecute(String result) {
            if (result != null) {
                CustomProgressbar.Progressbarcancel(getActivity());
            }
            try {

                JSONObject jsonObject = new JSONObject( result );
                String status = jsonObject.getString( "status" );
                if (status.equalsIgnoreCase( "200" )) {
                    String results = jsonObject.getString( "results" );
                    userslist = JsonParsing.GetJsonData( results );
                   /* if (userslist.size()>0){
                        customRecyclerview.Assigndatatorecyleviewhashmap( profile_search_recycle, userslist, "Searchpage", StoredObjects.Listview, 0, StoredObjects.ver_orientation, R.layout.search_listitems );
                        profile_search_recycle.setVisibility(View.VISIBLE);
                        cardview.setVisibility(View.VISIBLE);
                        prdct_nodata_txt.setVisibility(View.GONE);
                    }
                } else {
                    profile_search_recycle.setVisibility( View.GONE );
                    prdct_nodata_txt.setVisibility( View.VISIBLE );
                    cardview.setVisibility( View.GONE );*/
                }

            } catch (JSONException e) {
                e.printStackTrace();
            } catch (NullPointerException e) {
                // TODO: handle exception
            } catch (IllegalStateException e) {
                // TODO: handle exception
            } catch (IllegalArgumentException e) {
                // TODO: handle exception
            } catch (NetworkOnMainThreadException e) {
                // TODO: handle exception
            } catch (RuntimeException e) {
                // TODO: handle exception
            } catch (Exception e) {
                StoredObjects.LogMethod( "response", "response:---" + e );
            }
        }
    }

}
