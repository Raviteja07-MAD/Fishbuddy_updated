package com.fishbuddy.fragments;

import android.os.AsyncTask;
import android.os.Bundle;
import android.os.NetworkOnMainThreadException;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.fishbuddy.R;
import com.fishbuddy.customadapter.CustomRecyclerview;
import com.fishbuddy.customadapter.HashMapRecycleviewadapter;
import com.fishbuddy.customfonts.CustomRegularTextView;
import com.fishbuddy.servicesparsing.CustomProgressbar;
import com.fishbuddy.servicesparsing.HttpPostClass;
import com.fishbuddy.servicesparsing.InterNetChecker;
import com.fishbuddy.servicesparsing.JsonParsing;
import com.fishbuddy.sidemenu.SideMenu;
import com.fishbuddy.storedobjects.StoredObjects;
import com.fishbuddy.storedobjects.StoredUrls;

import org.apache.http.NameValuePair;
import org.apache.http.conn.ConnectTimeoutException;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.net.SocketTimeoutException;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import static com.fishbuddy.sidemenu.SideMenu.btm_notifications_img;
import static com.fishbuddy.sidemenu.SideMenu.btm_notifications_lay;
import static com.fishbuddy.sidemenu.SideMenu.btm_notifications_txt;
import static com.fishbuddy.sidemenu.SideMenu.buttonchangemethod;

public class Notifications extends Fragment {
    RecyclerView notifications_recyclerview;
    CustomRecyclerview customRecyclerview;
    TextView title_txt;
    public ArrayList<HashMap<String, String>> getpostlist = new ArrayList<>();
    public ArrayList<HashMap<String, String>> getpostlistall = new ArrayList<>();
    String total_results = "0",total_pages = "0",results_count = "0";
    int pageCount = 1;
    public static HashMapRecycleviewadapter adapter;
    CustomRegularTextView nodatafound_txt;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate( R.layout.notifications,null,false );
        StoredObjects.page_type="notifications";
        StoredObjects.back_type="notifications";
        buttonchangemethod (getActivity() , btm_notifications_lay , btm_notifications_img , btm_notifications_txt , "3");
        SideMenu.updatemenu(StoredObjects.page_type);
        initilization(v);
        StoredObjects.LogMethod("val","val:::"+"yes"+getpostlist.size());
        loadpostsdata(pageCount);
        return v;
    }

    public void loadpostsdata(int pageCount){

        if (InterNetChecker.isNetworkAvailable(getActivity())) {
            new NotificationTask().execute(StoredObjects.UserId,pageCount+"");
        }else{
            StoredObjects.ToastMethod(getActivity().getResources().getString(R.string.checkinternet),getActivity());
        }
    }

    private void initilization(View v) {
        notifications_recyclerview = (RecyclerView) v.findViewById( R.id.notifications_recyclerview );
        customRecyclerview = new CustomRecyclerview(getActivity());
        nodatafound_txt = (CustomRegularTextView)v.findViewById( R.id.nodatafound_txt );
        title_txt = (TextView)v.findViewById( R.id. title_txt);
        title_txt.setText( R.string.notfications );
        ImageView settings_img = (ImageView)v.findViewById( R.id.settings_img );
        settings_img.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                fragmentcallinglay( new Notifications_settings() );

            }
        } );

        ImageView backbtn_img = (ImageView)v.findViewById( R.id.backbtn_img );
        backbtn_img.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View view) {

               fragmentcallinglay( new Landing_page() );

            }
        } );
        final LinearLayoutManager linearLayoutManager=new LinearLayoutManager(getActivity());
        notifications_recyclerview.setLayoutManager(linearLayoutManager);


        notifications_recyclerview.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(RecyclerView recyclerView, int newState) {
                super.onScrollStateChanged(recyclerView, newState);

                int lastvisibleitemposition = linearLayoutManager.findLastVisibleItemPosition();

                if (lastvisibleitemposition == adapter.getItemCount() - 1) {

                    //pageCount=pageCount+1;
                    if(pageCount<Integer.parseInt(total_pages)){
                        pageCount=pageCount+1;
                        if (InterNetChecker.isNetworkAvailable(getActivity())) {
                            new NotificationLoadTask().execute(StoredObjects.UserId,pageCount+"");
                        }else{
                            StoredObjects.ToastMethod(getActivity().getResources().getString(R.string.checkinternet),getActivity());
                        }

                    }


                }
            }
        });


      /*  StoredObjects.hashmaplist(10);
          customRecyclerview.Assigndatatorecyleviewhashmap(notifications_recyclerview, StoredObjects.dummy_list,"notifications", StoredObjects.Listview, 0, StoredObjects.ver_orientation, R.layout.notifications_listitems);
    */

    }
    public void fragmentcallinglay(Fragment fragment) {

        FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
        fragmentManager.beginTransaction().replace(R.id.frame_container, fragment).addToBackStack("").commit();
    }


    public class NotificationTask extends AsyncTask<String, String, String> {
        String strResult = "";

        @Override
        protected void onPreExecute() {
               CustomProgressbar.Progressbarshow( getActivity() );
        }

        @Override
        protected String doInBackground(String... params) {
            try {
                List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>( 2 );
                //nameValuePairs.add( new BasicNameValuePair( "token", "Mikel") );
                nameValuePairs.add( new BasicNameValuePair( "method", "notifications" ) );
                nameValuePairs.add( new BasicNameValuePair( "customer_id",params[0] ) );
                nameValuePairs.add( new BasicNameValuePair( "page", params[1] ) );
                strResult = HttpPostClass.PostMethod( StoredUrls.BaseUrl, nameValuePairs );
            } catch (URISyntaxException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } catch (SocketTimeoutException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } catch (ConnectTimeoutException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } catch (UnsupportedEncodingException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            return strResult;
        }

        protected void onPostExecute(String result) {
            if (result != null) {
                   CustomProgressbar.Progressbarcancel(getActivity());
            }
            try {

                JSONObject jsonObject = new JSONObject( result );
                String status = jsonObject.getString( "status" );
                if (status.equalsIgnoreCase( "200" )) {
                    String results = jsonObject.getString( "results" );
                    total_results = jsonObject.getString( "total_results" );
                    results_count = jsonObject.getString( "results_count" );
                    total_pages = jsonObject.getString( "total_pages" );
                   // progressBar1.setVisibility( View.GONE );

                    if(pageCount==1){
                        getpostlist.clear();
                        getpostlistall = JsonParsing.GetJsonData( results );
                        getpostlist.addAll(getpostlistall);
                       // mShimmerViewContainer.setVisibility(View.GONE);
                        notifications_recyclerview.setVisibility( View.VISIBLE );
                        nodatafound_txt.setVisibility( View.GONE );
                       // nodatafound_lay.setVisibility( View.GONE );
                        adapter = new HashMapRecycleviewadapter( getActivity(), getpostlist, "notifications", notifications_recyclerview, R.layout.notifications_listitems );
                        notifications_recyclerview.setAdapter( adapter );


                    }else{
                        getpostlistall = JsonParsing.GetJsonData(results);
                        getpostlist.addAll(getpostlistall);
                        adapter = new HashMapRecycleviewadapter( getActivity(), getpostlist, "notifications", notifications_recyclerview, R.layout.notifications_listitems );
                        notifications_recyclerview.setAdapter( adapter );
                        adapter.notifyDataSetChanged();
                        notifications_recyclerview.invalidate();
                    }


                }else{

                    if(getpostlist.size() > 0){
                        notifications_recyclerview.setVisibility(View.GONE);
                        adapter = new HashMapRecycleviewadapter( getActivity(), getpostlist, "notifications", notifications_recyclerview, R.layout.notifications_listitems );
                        notifications_recyclerview.setAdapter( adapter );
                        adapter.notifyDataSetChanged();
                        notifications_recyclerview.invalidate();
                        nodatafound_txt.setVisibility(View.VISIBLE);
                    }else{
                        notifications_recyclerview.setVisibility(View.GONE);
                        nodatafound_txt.setVisibility(View.VISIBLE);
                      //  mShimmerViewContainer.setVisibility(View.GONE);
                    }


                }

            } catch (JSONException e) {
                e.printStackTrace();
            } catch (NullPointerException e) {
                // TODO: handle exception
            } catch (IllegalStateException e) {
                // TODO: handle exception
            } catch (IllegalArgumentException e) {
                // TODO: handle exception
            } catch (NetworkOnMainThreadException e) {
                // TODO: handle exception
            } catch (RuntimeException e) {
                // TODO: handle exception
            } catch (Exception e) {
                StoredObjects.LogMethod( "response", "response:---" + e );
            }
        }
    }

    public class NotificationLoadTask extends AsyncTask<String, String, String> {
        String strResult = "";

        @Override
        protected void onPreExecute() {
            CustomProgressbar.Progressbarshow( getActivity() );
        }

        @Override
        protected String doInBackground(String... params) {
            try {
                List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>( 2 );
                //nameValuePairs.add( new BasicNameValuePair( "token", "Mikel") );
                nameValuePairs.add( new BasicNameValuePair( "method", "notifications" ) );
                nameValuePairs.add( new BasicNameValuePair( "customer_id",params[0] ) );
                nameValuePairs.add( new BasicNameValuePair( "page", params[1] ) );
                strResult = HttpPostClass.PostMethod( StoredUrls.BaseUrl, nameValuePairs );
            } catch (URISyntaxException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } catch (SocketTimeoutException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } catch (ConnectTimeoutException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } catch (UnsupportedEncodingException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            return strResult;
        }

        protected void onPostExecute(String result) {
            if (result != null) {
                CustomProgressbar.Progressbarcancel(getActivity());
            }
            try {

                JSONObject jsonObject = new JSONObject( result );
                String status = jsonObject.getString( "status" );
                if (status.equalsIgnoreCase( "200" )) {
                    String results = jsonObject.getString( "results" );
                    total_results = jsonObject.getString( "total_results" );
                    results_count = jsonObject.getString( "results_count" );
                    total_pages = jsonObject.getString( "total_pages" );
                    // progressBar1.setVisibility( View.GONE );

                    if(pageCount==1){
                        getpostlist.clear();
                        getpostlistall = JsonParsing.GetJsonData( results );
                        getpostlist.addAll(getpostlistall);
                        // mShimmerViewContainer.setVisibility(View.GONE);
                        notifications_recyclerview.setVisibility( View.VISIBLE );
                        // nodatafound_lay.setVisibility( View.GONE );
                        adapter = new HashMapRecycleviewadapter( getActivity(), getpostlist, "notifications", notifications_recyclerview, R.layout.notifications_listitems );
                        notifications_recyclerview.setAdapter( adapter );


                    }else{
                        getpostlistall = JsonParsing.GetJsonData(results);
                        getpostlist.addAll(getpostlistall);
                        //StoredObjects.LogMethod("val","val:::"+"yes"+getpostlist.size());
                        adapter.notifyDataSetChanged();
                        notifications_recyclerview.invalidate();
                    }


                }else{

                    if(getpostlist.size() == 0){
                        notifications_recyclerview.setVisibility(View.GONE);
                        adapter.notifyDataSetChanged();
                        notifications_recyclerview.invalidate();
                        //nodatafound_txt.setVisibility(View.VISIBLE);
                    }else{
                        notifications_recyclerview.setVisibility(View.VISIBLE);
                        adapter.notifyDataSetChanged();
                        notifications_recyclerview.invalidate();
                        //nodatafound_txt.setVisibility(View.GONE);
                        //  mShimmerViewContainer.setVisibility(View.GONE);
                    }


                }

            } catch (JSONException e) {
                e.printStackTrace();
            } catch (NullPointerException e) {
                // TODO: handle exception
            } catch (IllegalStateException e) {
                // TODO: handle exception
            } catch (IllegalArgumentException e) {
                // TODO: handle exception
            } catch (NetworkOnMainThreadException e) {
                // TODO: handle exception
            } catch (RuntimeException e) {
                // TODO: handle exception
            } catch (Exception e) {
                StoredObjects.LogMethod( "response", "response:---" + e );
            }
        }
    }

}
