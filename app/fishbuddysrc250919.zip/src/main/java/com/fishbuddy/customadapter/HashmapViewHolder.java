package com.fishbuddy.customadapter;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.media.MediaMetadataRetriever;
import android.media.ThumbnailUtils;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.view.View;
import android.view.Window;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.fishbuddy.R;
import com.fishbuddy.circularimageview.CircularImageView;
import com.fishbuddy.customfonts.CustomButton;
import com.fishbuddy.customfonts.CustomRegularTextView;
import com.fishbuddy.fragments.Comments;
import com.fishbuddy.fragments.Fishingspots_details;
import com.fishbuddy.fragments.Followers_profile;
import com.fishbuddy.fragments.Landingdetails;
import com.fishbuddy.storedobjects.StoredObjects;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Objects;

import static com.fishbuddy.fragments.Comments.comments_lay;

class HashmapViewHolder extends RecyclerView.ViewHolder {

    private Activity activity;
    HashMapRecycleviewadapter adapter;

    CustomRegularTextView level_txt,count_txt;

    CustomRegularTextView document_txt,image_txt,status_txt;

    //landingpage
    private LinearLayout landing_listitems_lay,share__lay,comment__lay,like__lay;
    private ImageView like_img;
    private CustomRegularTextView like_txt;

    //fishingspots
    private LinearLayout fishingspots_lay,directions_lay;

    // fishbreeds
    private LinearLayout fishbreed_lay;

    //fishing_tricks
    private CustomRegularTextView int_count_txt;
    private ImageView fishingtricks_img;

   // following_profile
    CircularImageView profile_circular_img;
    CustomButton follow_btn;

    //profile_followers
    LinearLayout followers_profile_lay;
    Bitmap bmThumbnail;
    private static int count = 0;


    HashmapViewHolder(View convertView, String type, final Activity activity) {

        super(convertView);
        this.activity = activity;

        if (type.equalsIgnoreCase("landingpage")) {

            landing_listitems_lay =convertView.findViewById(R.id.landing_listitems_lay);
            share__lay = convertView.findViewById( R.id.share__lay );
            comment__lay = convertView.findViewById(R.id.comment__lay);
            like__lay = convertView.findViewById( R.id.like__lay );
            like_img = convertView.findViewById( R.id.like_img );
            like_txt = convertView.findViewById( R.id.like_txt );

        }
        if (type.equalsIgnoreCase("fishingspots")) {

            fishingspots_lay = convertView.findViewById(R.id.fishingspots_lay);
            directions_lay = convertView.findViewById( R.id.directions_lay );

        }

        if (type.equalsIgnoreCase("fishbreeds")) {

            fishbreed_lay =convertView.findViewById(R.id.fishbreed_lay);
        }
        if (type.equalsIgnoreCase("fishing_tricks")) {

            int_count_txt = convertView.findViewById(R.id.int_count_txt);
            CustomRegularTextView fishing_tricks_txt = convertView.findViewById( R.id.fishing_tricks_txt );
            fishingtricks_img = convertView.findViewById( R.id.fishingtricks_img );
        }
        if (type.equalsIgnoreCase("following_profile")) {

            profile_circular_img = convertView.findViewById(R.id.profile_circular_img);
            CustomRegularTextView profile_name_txt = convertView.findViewById( R.id.profile_name_txt );
            follow_btn = convertView.findViewById( R.id.follow_btn );
        }
        if (type.equalsIgnoreCase("profile_followers")) {

            followers_profile_lay = convertView.findViewById(R.id.followers_profile_lay);
        }

    }

    void assign_data(final ArrayList<HashMap<String, String>> datalist, final int position, String formtype) {

        if (formtype.equalsIgnoreCase("landingpage")) {
            landing_listitems_lay.setOnClickListener( new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    fragmentcalling( new Comments() );
                }
            } );
            share__lay.setOnClickListener( new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent sharingIntent = new Intent(Intent.ACTION_SEND);
                    sharingIntent.setType("text/plain");
                    sharingIntent.putExtra(Intent.EXTRA_TEXT,
                            "www.google.com");
                    sharingIntent.putExtra(Intent.EXTRA_SUBJECT, "Subject");
                    activity.startActivity(Intent.createChooser(sharingIntent, "Share using"));
                }
            } );
            comment__lay.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    fragmentcalling( new Comments() );
                }
            });
            like__lay.setOnClickListener( new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    count++;
                    if (count == 1) {
                        like_img.setImageResource( R.drawable.liked );
                        like_txt.setTextColor( activity.getResources().getColor(R.color.orange) );
                    } else {
                        count = 0;
                        like_img.setImageResource( R.drawable.like_button );
                        like_txt.setTextColor( activity.getResources().getColor(R.color.lite_color_text) );
                    }
                }
            } );
        }
        if (formtype.equalsIgnoreCase("fishingspots")) {
            fishingspots_lay.setOnClickListener( new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    fragmentcalling( new Fishingspots_details() );
                }
            } );
            directions_lay.setOnClickListener( new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    try {
                        String url = "https://www.google.com/maps/dir/?api=1&destination=" + 56.9539 + "° N"+"," + 5.7172+"° W" /*"&travelmode=driving"*/;
                        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                        activity.startActivity(intent);
                    }catch (Exception e){
                        StoredObjects.ToastMethod(" Address Not found",activity);
                    }
/*
                    new Handler().postDelayed( new Runnable() {
                        @Override
                        public void run() {
                            Uri gmmIntentUri = Uri.parse("geo:25.2744,133.7751?q=");
                            Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
                            mapIntent.setPackage("com.google.android.apps.maps");
                            activity.startActivity(mapIntent);
                        }
                    }, 1000);
*/
                }
            } );
        }
        if (formtype.equalsIgnoreCase("fishbreeds")) {
            fishbreed_lay.setOnClickListener( new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    fishbreeds_details_popup(activity);
                }
            } );
        }
        if (formtype.equalsIgnoreCase("fishing_tricks")) {
            int_count_txt.setText(Integer.toString(position));

          /*  Bitmap thumb = ThumbnailUtils.createVideoThumbnail("https://www.youtube.com/watch?v=uilkmUoXoLU",
                    MediaStore.Images.Thumbnails.MINI_KIND);
            fishingtricks_img.setImageBitmap( thumb );*/
/*
            Glide.with(activity)
                    .load("https://www.youtube.com/watch?v=uilkmUoXoLU") // or URI/path
                    .into(fishingtricks_img);
*/

/*
            Glide.with(activity)
                    .load("file:///storage/emulated/0/WhatsApp/Media/WhatsApp Video/VID-20190923-WA0000.mp4")
                    .centerCrop()
                    .placeholder(Color.BLUE)
                    .crossFade()
                    .into(fishingtricks_img);
*/
        }
        if (formtype.equalsIgnoreCase("following_profile")) {
            profile_circular_img.setOnClickListener( new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                   fragmentcalling( new Followers_profile() );
                }
            } );
        }
        if (formtype.equalsIgnoreCase("profile_followers")) {
            followers_profile_lay.setOnClickListener( new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    fragmentcalling( new Followers_profile() );
                }
            } );
        }

    }
    private void fragmentcalling(Fragment fragment) {
        FragmentManager fragmentManager = ((FragmentActivity)activity).getSupportFragmentManager();
        fragmentManager.beginTransaction().replace(R.id.frame_container, fragment).addToBackStack("").commit();
    }

    private void fishbreeds_details_popup(final Activity activity) {
        final Dialog dialog = new Dialog(activity);
        dialog.getWindow();
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.fishbreeddetails_popup);
        Objects.requireNonNull( dialog.getWindow() ).setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.getWindow().setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);

        CustomButton fishbreed_additiondetails_btn = (CustomButton) dialog.findViewById(R.id.fishbreed_additiondetails_btn);
        ImageView canclimg = (ImageView) dialog.findViewById(R.id.canclimg);

        fishbreed_additiondetails_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                fishbreeds_additionaldetails_popup(activity);
                dialog.dismiss();
            }
        });

        canclimg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss();
            }
        });
        dialog.show();
    }

    private void fishbreeds_additionaldetails_popup(final Activity activity) {
        final Dialog dialog = new Dialog(activity);
        dialog.getWindow();
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.fishbreed_additiondetails_popup);
        Objects.requireNonNull( dialog.getWindow() ).setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.getWindow().setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);

        ImageView canclimg = (ImageView) dialog.findViewById(R.id.canclimg);
        canclimg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss();
            }
        });
        dialog.show();
    }
}
