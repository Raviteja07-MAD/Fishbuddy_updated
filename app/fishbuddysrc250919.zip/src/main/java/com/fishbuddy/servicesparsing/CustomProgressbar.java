package com.fishbuddy.servicesparsing;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.view.Window;
import android.widget.LinearLayout;

import com.fishbuddy.R;


public class CustomProgressbar {

	public static Dialog dialog;
	public static void Progressbarshow(Context context) {

		if(context!=null){
			dialog = new Dialog(context);
			dialog.getWindow();
			dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
			dialog.setContentView( R.layout.customprogressbar);
			dialog.setCancelable(true);
			dialog.setCanceledOnTouchOutside(true);
			dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.parseColor("#2BFFFFFF")));

			dialog.getWindow().setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT);
			dialog.show();
		}

	}

	public static void Progressbarcancel(Context context) {
		if(context != null){


			if (dialog != null) {
				dialog.dismiss();
			}
		}

	}





}
