package com.fishbuddy.fragments;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.fishbuddy.R;
import com.fishbuddy.sidemenu.SideMenu;
import com.fishbuddy.storedobjects.StoredObjects;

public class Fishingspots_details extends Fragment {
    TextView title_txt;
    LinearLayout locate_lake_lay;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate( R.layout.fishingspotsdetails,null,false );
        StoredObjects.page_type="fishingspotsdetails";
        StoredObjects.page_type="fishingspotsdetails";
        SideMenu.updatemenu(StoredObjects.page_type);
        initilization(v);
        return v;
    }

    private void initilization(View v) {

         title_txt = (TextView)v.findViewById( R.id. title_txt);
        title_txt.setText( R.string.lakename );

        ImageView backbtn_img = (ImageView)v.findViewById( R.id.backbtn_img );
        backbtn_img.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                assert getFragmentManager() != null;
                getFragmentManager().popBackStack();
            }
        } );

        locate_lake_lay = (LinearLayout)v.findViewById( R.id.locate_lake_lay );
        locate_lake_lay.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    String url = "https://www.google.com/maps/dir/?api=1&destination=" + 56.9539 + "° N"+"," + 5.7172+"° W" /*"&travelmode=driving"*/;
                    Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                    getContext().startActivity(intent);
                }catch (Exception e){
                    StoredObjects.ToastMethod("No Lakes found",getActivity());
                }

            }
        } );
    }
}
