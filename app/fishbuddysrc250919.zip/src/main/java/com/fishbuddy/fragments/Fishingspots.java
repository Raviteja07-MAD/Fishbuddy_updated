package com.fishbuddy.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;

import com.fishbuddy.R;
import com.fishbuddy.customadapter.CustomRecyclerview;
import com.fishbuddy.sidemenu.SideMenu;
import com.fishbuddy.storedobjects.StoredObjects;

public class Fishingspots extends Fragment {
    RecyclerView fishingspot_recyclerview;
    CustomRecyclerview customRecyclerview;
    TextView title_txt;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate( R.layout.fishingspots,null,false );
        StoredObjects.page_type="fishingspots";
        StoredObjects.back_type="fishingspots";
        SideMenu.updatemenu(StoredObjects.page_type);
        initilization(v);
        return v;
    }

    private void initilization(View v) {
        fishingspot_recyclerview = (RecyclerView) v.findViewById( R.id.fishingspot_recyclerview );
        customRecyclerview = new CustomRecyclerview(getActivity());

        title_txt = (TextView)v.findViewById( R.id. title_txt);
        title_txt.setText( R.string.fishingspots );

        ImageView backbtn_img = (ImageView)v.findViewById( R.id.backbtn_img );
        backbtn_img.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                assert getFragmentManager() != null;
                getFragmentManager().popBackStack();

            }
        } );

        StoredObjects.hashmaplist(4);
          customRecyclerview.Assigndatatorecyleviewhashmap(fishingspot_recyclerview, StoredObjects.dummy_list,"fishingspots", StoredObjects.Listview, 0, StoredObjects.ver_orientation, R.layout.fishingspots_listitem);


    }
}
