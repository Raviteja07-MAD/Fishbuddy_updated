package com.fishbuddy.fragments;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.NetworkOnMainThreadException;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.RecyclerView;

import com.fishbuddy.Activities.Forgot_password;
import com.fishbuddy.Activities.Sign_in_Sign_up;
import com.fishbuddy.R;
import com.fishbuddy.customadapter.CustomRecyclerview;
import com.fishbuddy.customfonts.CustomButton;
import com.fishbuddy.customfonts.CustomEditText;
import com.fishbuddy.servicesparsing.CustomProgressbar;
import com.fishbuddy.servicesparsing.HttpPostClass;
import com.fishbuddy.servicesparsing.InterNetChecker;
import com.fishbuddy.sidemenu.SideMenu;
import com.fishbuddy.storedobjects.StoredObjects;
import com.fishbuddy.storedobjects.StoredUrls;

import org.apache.http.NameValuePair;
import org.apache.http.conn.ConnectTimeoutException;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.net.SocketTimeoutException;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import static android.app.Activity.RESULT_OK;
import static com.fishbuddy.sidemenu.SideMenu.btm_addpost_img;
import static com.fishbuddy.sidemenu.SideMenu.btm_addpost_txt;
import static com.fishbuddy.sidemenu.SideMenu.btmaddpost_lay;

public class Addpost extends Fragment {
    TextView title_txt;
    ImageView backbtn_img;
    CustomEditText addpost_photo_video_edtxt;
    CustomButton post_btn;
    String PathHolder;
    Intent intent ;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate( R.layout.add_post,null,false );
        StoredObjects.page_type="home";
        StoredObjects.back_type="add_post";
        SideMenu.buttonchangemethod (getActivity() , btmaddpost_lay , btm_addpost_img , btm_addpost_txt , "1");
        SideMenu.updatemenu(StoredObjects.page_type);
        initilization(v);
        return v;
    }

    private void initilization(View v) {

        title_txt = (TextView)v.findViewById( R.id. title_txt);
        backbtn_img = (ImageView)v.findViewById( R.id.backbtn_img );
        addpost_photo_video_edtxt = (CustomEditText)v.findViewById( R.id.addpost_photo_video_edtxt );
        post_btn = (CustomButton)v.findViewById( R.id.post_btn );

        title_txt.setText( R.string.addpost );
        backbtn_img.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               fragmentcallinglay( new Landing_page() );
            }
        } );
        addpost_photo_video_edtxt.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showFileChooser();
            }
        } );
        post_btn.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (InterNetChecker.isNetworkAvailable( getActivity() )) {
                    new UploadTask().execute(PathHolder );
                } else {
                    StoredObjects.ToastMethod( getActivity().getResources().getString( R.string.checkinternet ), getActivity());
                }
            }
        } );

    }

    public void showFileChooser() {

        intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("*/*");
        intent.putExtra( Intent.EXTRA_MIME_TYPES,new String[]{"image/*","video/*"} );
        startActivityForResult(intent, 7);

    }
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        // TODO Auto-generated method stub

        if (requestCode == 7) {
            if (resultCode == RESULT_OK) {

                PathHolder = Objects.requireNonNull( data.getData() ).getPath();

                addpost_photo_video_edtxt.setText(PathHolder);

                Toast.makeText( getActivity(), PathHolder, Toast.LENGTH_SHORT ).show();

            }
        }
    }
    public void fragmentcallinglay(Fragment fragment) {

        FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
        fragmentManager.beginTransaction().replace(R.id.frame_container, fragment).addToBackStack("").commit();
    }

    public class UploadTask extends AsyncTask<String, String, String> {
        String strResult = "";
        @Override
        protected void onPreExecute() {
            CustomProgressbar.Progressbarshow( getActivity());
        }
        @Override
        protected String doInBackground(String... params) {
            try {
                List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(2);
                nameValuePairs.add(new BasicNameValuePair("token","Mikel"));
                nameValuePairs.add(new BasicNameValuePair("uploaded_file ",params[0]));
                nameValuePairs.add(new BasicNameValuePair("method","upload-file"));
                strResult = HttpPostClass.PostMethod( StoredUrls.BaseUrl,nameValuePairs);
            } catch (URISyntaxException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } catch (SocketTimeoutException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } catch (ConnectTimeoutException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } catch (UnsupportedEncodingException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            return strResult;
        }

        protected void onPostExecute(String result) {
            if (result != null) {
                CustomProgressbar.Progressbarcancel(getActivity());
            }
            try {

                JSONObject jsonObject =  new JSONObject(result);
                String status = jsonObject.getString("status");
                if(status.equalsIgnoreCase("200")){
                    StoredObjects.ToastMethod("Image uploaded succesfully",getActivity());
                    startActivity(new Intent(getActivity(), Sign_in_Sign_up.class));
                }else{
                    String error= jsonObject.getString("error");
                    StoredObjects.ToastMethod(error,getActivity());
                }

            } catch (JSONException e) {
                e.printStackTrace();
            }
            catch (NullPointerException e) {
                // TODO: handle exception
            }catch (IllegalStateException e) {
                // TODO: handle exception
            }catch (IllegalArgumentException e) {
                // TODO: handle exception
            }catch (NetworkOnMainThreadException e) {
                // TODO: handle exception
            }catch (RuntimeException e) {
                // TODO: handle exception
            }
            catch (Exception e) {
                StoredObjects.LogMethod("response", "response:---"+e);
            }
        }
    }

}
