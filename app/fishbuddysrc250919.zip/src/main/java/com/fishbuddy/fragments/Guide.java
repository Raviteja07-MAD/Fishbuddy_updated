package com.fishbuddy.fragments;

import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.VideoView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;

import com.fishbuddy.R;
import com.fishbuddy.customadapter.CustomRecyclerview;
import com.fishbuddy.sidemenu.SideMenu;
import com.fishbuddy.storedobjects.StoredObjects;

public class Guide extends Fragment {
    TextView title_txt;
    CustomRecyclerview customRecyclerview;


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate( R.layout.guide,null,false );
        StoredObjects.page_type="home";
        StoredObjects.back_type="guide";
        SideMenu.updatemenu(StoredObjects.page_type);
        initilization(v);
        return v;
    }


    private void initilization(View v) {

        RecyclerView fishing_tricks_recycle = (RecyclerView) v.findViewById( R.id.fishing_tricks_recycle );
        customRecyclerview = new CustomRecyclerview(getActivity());
        title_txt = (TextView)v.findViewById( R.id. title_txt);
        title_txt.setText( R.string.fishingtips );
        ImageView backbtn_img = (ImageView)v.findViewById( R.id.backbtn_img );
        backbtn_img.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                assert getFragmentManager() != null;
                getFragmentManager().popBackStack();

            }
        } );

        StoredObjects.hashmaplist(5);
        customRecyclerview.Assigndatatorecyleviewhashmap( fishing_tricks_recycle, StoredObjects.dummy_list,"fishing_tricks", StoredObjects.Listview, 0, StoredObjects.ver_orientation, R.layout.guide_listitems);

    }
}
