package com.fishbuddy.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;

import com.fishbuddy.R;
import com.fishbuddy.customadapter.CustomRecyclerview;
import com.fishbuddy.sidemenu.SideMenu;
import com.fishbuddy.storedobjects.StoredObjects;

public class Notifications extends Fragment {
    RecyclerView notifications_recyclerview;
    CustomRecyclerview customRecyclerview;
    TextView title_txt;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate( R.layout.notifications,null,false );
        StoredObjects.page_type="notifications";
        SideMenu.updatemenu(StoredObjects.page_type);
        initilization(v);
        return v;
    }

    private void initilization(View v) {
        notifications_recyclerview = (RecyclerView) v.findViewById( R.id.notifications_recyclerview );
        customRecyclerview = new CustomRecyclerview(getActivity());

        title_txt = (TextView)v.findViewById( R.id. title_txt);
        title_txt.setText( "Notifications" );

        StoredObjects.hashmaplist(10);
          customRecyclerview.Assigndatatorecyleviewhashmap(notifications_recyclerview, StoredObjects.dummy_list,"notifications", StoredObjects.Listview, 0, StoredObjects.ver_orientation, R.layout.notifications_listitems);


    }
}
