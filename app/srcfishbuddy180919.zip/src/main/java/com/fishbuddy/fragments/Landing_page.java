package com.fishbuddy.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.widget.AbsListView;
import android.widget.FrameLayout;
import android.widget.LinearLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.RecyclerView;

import com.fishbuddy.R;
import com.fishbuddy.customadapter.CustomRecyclerview;
import com.fishbuddy.sidemenu.SideMenu;
import com.fishbuddy.storedobjects.StoredObjects;

public class Landing_page  extends Fragment {
    RecyclerView landing_recycle;
    CustomRecyclerview customRecyclerview;
    LinearLayout fishing_spots_lay,top_lay,fish_breads_lay,guide_lay,popular_lay;


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate( R.layout.landingpage,null,false );
        StoredObjects.page_type="landingpage";
        SideMenu.updatemenu(StoredObjects.page_type);
        initilization(v);
        return v;
    }

    private void initilization(View v) {
        landing_recycle = (RecyclerView) v.findViewById( R.id.landing_recycle );
        customRecyclerview = new CustomRecyclerview(getActivity());
        fishing_spots_lay = (LinearLayout)v.findViewById( R.id.fishing_spots_lay );
        top_lay = (LinearLayout)v.findViewById( R.id.top_lay );
        fish_breads_lay = (LinearLayout)v.findViewById( R.id.fish_breads_lay );
        guide_lay = (LinearLayout)v.findViewById(R.id.guide_lay);
        popular_lay = (LinearLayout)v.findViewById(R.id.popular_lay);

        fishing_spots_lay.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                fragmentcallinglay( new Fishingspots() );
            }
        } );

        fish_breads_lay.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                fragmentcallinglay( new FishBreeds() );
            }
        } );

        guide_lay.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                fragmentcallinglay( new Guide() );
            }
        } );
        popular_lay.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                fragmentcallinglay( new Popular() );
            }
        } );



        StoredObjects.hashmaplist(4);
          customRecyclerview.Assigndatatorecyleviewhashmap(landing_recycle, StoredObjects.dummy_list,"landingpage", StoredObjects.Listview, 0, StoredObjects.ver_orientation, R.layout.landing_listitems);

    }

    public void fragmentcallinglay(Fragment fragment) {

        FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
        fragmentManager.beginTransaction().replace(R.id.frame_container, fragment).addToBackStack("").commit();
    }


}
