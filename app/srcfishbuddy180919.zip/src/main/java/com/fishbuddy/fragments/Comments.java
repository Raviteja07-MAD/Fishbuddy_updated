package com.fishbuddy.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.RecyclerView;

import com.fishbuddy.R;
import com.fishbuddy.customadapter.CustomRecyclerview;
import com.fishbuddy.sidemenu.SideMenu;
import com.fishbuddy.storedobjects.StoredObjects;

public class Comments extends Fragment {
    RecyclerView comments_recycle;
    CustomRecyclerview customRecyclerview;
    TextView title_txt;



    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate( R.layout.comments,null,false );
        StoredObjects.page_type="comments";
        SideMenu.updatemenu(StoredObjects.page_type);
        initilization(v);
        return v;
    }

    private void initilization(View v) {
        comments_recycle = (RecyclerView) v.findViewById( R.id.comments_recycle );
        customRecyclerview = new CustomRecyclerview(getActivity());
        title_txt = (TextView)v.findViewById( R.id. title_txt);
        title_txt.setText( "Largemouth bass 3.4 kg" );

        StoredObjects.hashmaplist(4);
          customRecyclerview.Assigndatatorecyleviewhashmap(comments_recycle, StoredObjects.dummy_list,"comments", StoredObjects.Listview, 0, StoredObjects.ver_orientation, R.layout.comments_listitems);

    }

    public void fragmentcallinglay(Fragment fragment) {

        FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
        fragmentManager.beginTransaction().replace(R.id.frame_container, fragment).addToBackStack("").commit();
    }


}
