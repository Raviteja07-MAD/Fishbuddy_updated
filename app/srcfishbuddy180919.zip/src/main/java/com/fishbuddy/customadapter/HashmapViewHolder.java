package com.fishbuddy.customadapter;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.view.View;
import android.view.Window;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.RecyclerView;

import com.fishbuddy.R;
import com.fishbuddy.customfonts.CustomButton;
import com.fishbuddy.customfonts.CustomRegularTextView;
import com.fishbuddy.fragments.Comments;
import com.fishbuddy.fragments.Fishingspots_details;
import com.fishbuddy.fragments.Landingdetails;

import java.util.ArrayList;
import java.util.HashMap;

public class HashmapViewHolder extends RecyclerView.ViewHolder {

    Activity activity;
    HashMapRecycleviewadapter adapter;

    CustomRegularTextView level_txt,count_txt;

    CustomRegularTextView document_txt,image_txt,status_txt;

    //landingpage
    LinearLayout landing_listitems_lay,share__lay,comment__lay;

    //fishingspots
    LinearLayout fishingspots_lay;

    // fishbreeds
    LinearLayout fishbreed_lay;



    public HashmapViewHolder(View convertView, String type, final Activity activity) {

        super(convertView);
        this.activity = activity;

        if (type.equalsIgnoreCase("landingpage")) {

            landing_listitems_lay =convertView.findViewById(R.id.landing_listitems_lay);
            share__lay = convertView.findViewById( R.id.share__lay );
            comment__lay = convertView.findViewById(R.id.comment__lay);

        }
        if (type.equalsIgnoreCase("fishingspots")) {

            fishingspots_lay =convertView.findViewById(R.id.fishingspots_lay);

        }

        if (type.equalsIgnoreCase("fishbreeds")) {

            fishbreed_lay =convertView.findViewById(R.id.fishbreed_lay);

        }


    }

    public void assign_data(final ArrayList<HashMap<String, String>> datalist, final int position, String formtype) {

        if (formtype.equalsIgnoreCase("landingpage")) {

            landing_listitems_lay.setOnClickListener( new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    fragmentcalling( new Landingdetails() );

                }
            } );
            share__lay.setOnClickListener( new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent sharingIntent = new Intent(Intent.ACTION_SEND);
                    sharingIntent.setType("text/plain");
                    sharingIntent.putExtra(Intent.EXTRA_TEXT,
                            "");
                    sharingIntent.putExtra(Intent.EXTRA_SUBJECT, "Subject");
                    activity.startActivity(Intent.createChooser(sharingIntent, "Share using"));
                }
            } );
            comment__lay.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    fragmentcalling( new Comments() );

                }
            });

        }
        if (formtype.equalsIgnoreCase("fishingspots")) {

            fishingspots_lay.setOnClickListener( new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    fragmentcalling( new Fishingspots_details() );

                }
            } );

        }

        if (formtype.equalsIgnoreCase("fishbreeds")) {

            fishbreed_lay.setOnClickListener( new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    fishbreeds_details_popup(activity);

                }
            } );

        }



       /* if (formtype.equalsIgnoreCase("refsummary")) {

            level_txt.setText(datalist.get(position).get("Level"));
            count_txt.setText(datalist.get(position).get("Column1"));

        }

       else if (formtype.equalsIgnoreCase("getkyc")) {

            document_txt.setText(datalist.get(position).get("Document"));
            image_txt.setText(datalist.get(position).get("Img"));
            status_txt.setText(datalist.get(position).get("KYCStatus"));

        }

        else if (formtype.equalsIgnoreCase("settings")) {

            setng_prflenmes_txt.setText(datalist.get(position).get("title"));

            setng_prflelist_lay.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                *//*    if(StoredObjects.UserType.equalsIgnoreCase("Customer")){
                        if(position == 0){
                            fragmentcalling(new CustomerProfile());
                        } else if(position == 1){
                            fragmentcalling(new AddressesList());
                        } else if(position == 2){
                            fragmentcalling(new AvailableOffers());
                        } else if(position == 3){
                            fragmentcalling(new AddressesList());
                        }   else if(position ==4){
                            fragmentcalling(new ChangePassword());
                        }else if(position ==5){
                            Logoutpopup(activity);
                        }
                    }else if(StoredObjects.UserType.equalsIgnoreCase("Vendor")){
                        if(position == 0){
                            fragmentcalling(new CustomerProfile());
                        }  else if(position ==1){
                            fragmentcalling(new ChangePassword());
                        } else if(position ==2){
                            fragmentcalling(new PaymentHistory());
                        } else if(position ==3){
                            fragmentcalling(new AddOffer());
                        } else if(position ==4){
                            fragmentcalling(new AddProduct());
                        } else if(position ==5){
                            Logoutpopup(activity);
                        }

                    }else*//*{
                        if(position == 0){
                            fragmentcalling(new Profile());
                        }  else if(position ==1){
                            fragmentcalling(new AddressesList());
                        }else if(position ==2){
                            fragmentcalling(new Changepassword());
                        }
                        else if(position ==3){
                            Logoutpopup(activity);
                        }
                    }
                }
            });
        }


        else if (formtype.equalsIgnoreCase("c_addresslist")) {

            adreslst_edit_img.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                }
            });

            adreslst_delete_img.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                }
            });

        }*/

    }

    public void fragmentcalling(Fragment fragment) {
        FragmentManager fragmentManager = ((FragmentActivity)activity).getSupportFragmentManager();
        fragmentManager.beginTransaction().replace(R.id.frame_container, fragment).addToBackStack("").commit();
    }

/*
    private void Logoutpopup(final Activity activity) {
        final Dialog dialog = new Dialog(activity);
        dialog.getWindow();
        dialog.requestWindowFeature( Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.logoutpopup);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable( Color.TRANSPARENT));
        dialog.getWindow().setLayout( LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);

        LinearLayout cancel_lay = (LinearLayout)dialog.findViewById(R.id.cancel_lay);
        CustomButton ok_btn = (CustomButton)dialog.findViewById(R.id.ok_btn);
        CustomButton cancel_btn = (CustomButton)dialog.findViewById(R.id.cancel_btn);
        ImageView cancel_img = (ImageView)dialog.findViewById(R.id.cancel_img);

        cancel_lay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                dialog.dismiss();
            }
        });

        cancel_img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                dialog.dismiss();
            }
        });

        ok_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                activity.finish();
                Intent intent=new Intent(activity, Login.class);
                intent.setFlags( Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                activity.startActivity(intent);

            }
        });

        cancel_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                dialog.dismiss();
            }
        });

        dialog.show();
    }
*/

    private void fishbreeds_details_popup(final Activity activity) {
        final Dialog dialog = new Dialog(activity);
        dialog.getWindow();
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.fishbreeddetails_popup);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.getWindow().setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);

        CustomButton fishbreed_additiondetails_btn = (CustomButton) dialog.findViewById(R.id.fishbreed_additiondetails_btn);
        ImageView canclimg = (ImageView) dialog.findViewById(R.id.canclimg);

        fishbreed_additiondetails_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                fishbreeds_additionaldetails_popup(activity);
                dialog.dismiss();

            }
        });

        canclimg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss();
            }
        });


        dialog.show();

    }

    private void fishbreeds_additionaldetails_popup(final Activity activity) {
        final Dialog dialog = new Dialog(activity);
        dialog.getWindow();
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.fishbreed_additiondetails_popup);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.getWindow().setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);

        ImageView canclimg = (ImageView) dialog.findViewById(R.id.canclimg);

        canclimg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss();
            }
        });


        dialog.show();

    }



}
