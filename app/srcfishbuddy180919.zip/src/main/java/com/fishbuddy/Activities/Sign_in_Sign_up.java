package com.fishbuddy.Activities;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.fishbuddy.R;
import com.fishbuddy.customfonts.CustomButton;
import com.fishbuddy.customfonts.CustomRegularTextView;
import com.fishbuddy.sidemenu.SideMenu;

public class Sign_in_Sign_up extends AppCompatActivity {
    CustomRegularTextView sign_in_text,sign_up_text,frgt_password_text;
    LinearLayout sign_in_layout,signup_layout;
    CustomButton sign_in_btn;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.sign_in );
        initialization();
    }
    private void initialization() {

        sign_in_text = (CustomRegularTextView)findViewById( R.id.sign_in_text );
        sign_up_text = (CustomRegularTextView)findViewById( R.id.sign_up_text );
        frgt_password_text = (CustomRegularTextView)findViewById( R.id.frgt_password_text );
        sign_in_layout = (LinearLayout)findViewById( R.id.sign_in_layout );
        signup_layout = (LinearLayout)findViewById( R.id.signup_layout );
        sign_in_btn = (CustomButton)findViewById( R.id.sign_in_btn );

        sign_in_btn.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(Sign_in_Sign_up.this, SideMenu.class));

            }
        } );

        sign_in_text.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                buttonchangemethod (Sign_in_Sign_up.this ,sign_in_layout, sign_in_text  ,"0");
            }
        } );

        sign_up_text.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                buttonchangemethod (Sign_in_Sign_up.this ,signup_layout, sign_up_text  ,"1");
            }
        } );

    }

    public void buttonchangemethod(Activity activity ,LinearLayout layout1,  TextView text1 , String type) {

        signup_layout.setVisibility( View.GONE );
        sign_in_layout.setVisibility( View.GONE );

        sign_in_text.setBackgroundResource( R.drawable.signin_white_btn_bg );
        sign_up_text.setBackgroundResource( R.drawable.signin_white_btn_bg );

        sign_up_text.setTextColor( getResources().getColor(R.color.form_text_color));
        sign_in_text.setTextColor( getResources().getColor(R.color.form_text_color));


        layout1.setVisibility( View.VISIBLE );
        text1.setTextColor (activity.getResources ().getColor (R.color.white));
        text1.setBackgroundResource( R.drawable.signin_btn_bg );
    }

}
