package com.fishbuddy.Activities;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.os.Handler;

import android.util.Log;

import androidx.appcompat.app.AppCompatActivity;

import com.fishbuddy.R;


/**
 * Created by android-4 on 2/27/2019.
 */

public class Splash extends AppCompatActivity {

    private static final int TIME = 1 * 1000;// 4 seconds
   // Database database;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView( R.layout.splash);
        setRequestedOrientation ( ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
       // database = new Database(Splash.this);
        //database.getAllDevice();
    }

    @Override
    protected void onResume() {
        Log.i("onresume", "onresume");
        GenerateSplashScreenMethod();
        super.onResume();
    }


    public void GenerateSplashScreenMethod(){
        new Handler().postDelayed( new Runnable() {

            @Override
            public void run() {

                startActivity(new Intent(Splash.this, Sign_in_Sign_up.class));
                Splash.this.finish();



               /* if(StoredObjects.UserId.equalsIgnoreCase("0")){
                    startActivity(new Intent(Splash.this, Login.class));
                    Splash.this.finish();

                }else{
                    startActivity(new Intent(Splash.this, SideMenu.class));
                    Splash.this.finish();

                }*/



              /*//  StoredObjects.savedata(context,"slides","No");
                String val = StoredObjects.getsaveddata(Splash.this,"slides");
                Log.i("onresume", "onresume"+"<><>"+val);

               */



            }
        }, TIME);
    }


}