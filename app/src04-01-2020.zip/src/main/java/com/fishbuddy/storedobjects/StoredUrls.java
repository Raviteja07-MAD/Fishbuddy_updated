package com.fishbuddy.storedobjects;

/**
 * Created by Kiran on 30-10-2018.
 */

public class StoredUrls {



    public static String MainUrl = "http://fishbuddy.customerwebdemo.com/";
    //public static String MainUrl = "http://demos.customerwebdemo.com/FishBuddy";

    //Mainurl
    public static String BaseUrl=MainUrl+"/app/index.php?";

    public static String RequestMethod="POST";
    public static String ApplicationType="text/xml";
    public static String Bearer="FB8CFB5C-8E26-44A2-B213-B9086242F4BC";

    public static String Uploadimage_url=BaseUrl+"method=upload-file";
    public static String Uploadedimages =MainUrl+"/";//"http://demos.customerwebdemo.com/


    public static String imageupload=MainUrl+"//app/uploadfile.php?";//"http://demos.customerwebdemo.com/

    public static String youtubelink = "";





    public static String unlike_post = "unlike-post";
    public static String like_post = "like-post";

    public static String fish_breeds = "fish-breeds";

    public static String fishing_spots = "fishing-spots";
    public static String user_guide = "user-guide";

    public static String delete_post = "delete-post";
    public static String block_user = "block-user";
    public static String hidepost = "hide-post";

    public static String edit_post = "edit-post";

    public static String unfollow_user = "unfollow-user";
    public static String follow_profile = "follow-profile";

    public static String users_list = "users-list";





    //Dashboard

    public static String Userdashboard="User_Dashboard";
    public static String User_DashboardResponse="User_DashboardResponse";
    public static String User_DashboardResult="User_DashboardResult";

    //login
//   "uname=wadmin&pword=wadmin";
    public static String User_Validation="User_Validation";
    public static String User_ValidationResponse="User_ValidationResponse";
    public static String User_ValidationResult="User_ValidationResult";

    //Magic card
    public static String User_GetMagicCard="User_GetMagicCard";
    public static String User_GetMagicCardResponse="User_GetMagicCardResponse";
    public static String User_GetMagicCardResult="User_GetMagicCardResult";

    //Get profile
    public static String User_GetProfile="User_GetProfile";
    public static String User_GetProfileResponse="User_GetProfileResponse";
    public static String User_GetProfileResult="User_GetProfileResult";

    //Update profile
    public static String User_UpdateProfile="User_UpdateProfile";
    public static String User_UpdateProfileResponse="User_UpdateProfileResponse";
    public static String User_UpdateProfileResult="User_UpdateProfileResult";

    //Forgot password
    public static String User_Passwordhelp="User_Passwordhelp";
    public static String User_PasswordhelpResponse="User_PasswordhelpResponse";
    public static String User_PasswordhelpResult="User_PasswordhelpResult";

    //Registration
    public static String User_Registration="User_Registration";
    public static String User_RegistrationResponse="User_RegistrationResponse";
    public static String User_RegistrationResult="User_RegistrationResult";


    //Referal link
    public static String User_GetReferralLink="User_GetReferralLink";
    public static String User_GetReferralLinkResponse="User_GetReferralLinkResponse";
    public static String User_GetReferralLinkResult="User_GetReferralLinkResult";


    //Referal Sumary
    public static String User_GetReferralSummary="User_GetReferralSummary";
    public static String User_GetReferralSummaryResponse="User_GetReferralSummaryResponse";
    public static String User_GetReferralSummaryResult="User_GetReferralSummaryResult";


    //Change password
    public static String User_ChangePassowrd ="User_ChangePassowrd";
    public static String User_ChangePassowrdResponse ="User_ChangePassowrdResponse";
    public static String User_ChangePassowrdResult="User_ChangePassowrdResult";

    //Get Kyc
    public static String User_kYCGet ="User_kYCGet";
    public static String User_kYCGetResponse ="User_kYCGetResponse";
    public static String User_kYCGetResult="User_kYCGetResult";

    //Otp Validtaion

    public static String User_OTPValidation  ="User_OTPValidation";
    public static String User_OTPValidationResponse  ="User_OTPValidationResponse";
    public static String User_OTPValidationResult="User_OTPValidationResult";

    //Get referral phone
    public static String User_GetProfilebyMobileNo ="User_GetProfilebyMobileNo";
    public static String User_GetProfilebyMobileNoResponse ="User_GetProfilebyMobileNoResponse";
    public static String User_GetProfilebyMobileNoResult="User_GetProfilebyMobileNoResult";

    //Otp Validtaion

    public static String User_OTPRequest  ="User_OTPRequest";
    public static String User_OTPRequestResponse  ="User_OTPRequestResponse";
    public static String User_OTPRequestResult="User_OTPRequestResult";


    //Get Kyc
    public static String User_kYCEntry ="User_kYCEntry";
    public static String User_kYCEntryResponse ="User_kYCEntryResponse";
    public static String User_kYCEntryResult="User_kYCEntryResult";

    //Image upload
    public static String UploadFile ="UploadFile";

    //update Magic card
    public static String User_MagicCardUPDate="User_MagicCardUPDate";
    public static String User_MagicCardUPDateResponse="User_MagicCardUPDateResponse";
    public static String User_MagicCardUPDateResult="User_MagicCardUPDateResult";


}
